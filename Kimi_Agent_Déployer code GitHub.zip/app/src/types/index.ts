// ============================================================
// TYPES MONEY CONTROL PRO
// ============================================================

export type TransactionType = 'Revenu' | 'Dépense' | 'Épargne';
export type Priority = 'Haute' | 'Moyenne' | 'Basse';

export interface Transaction {
  id: number;
  date: string;
  mois: string;
  annee: number;
  type: TransactionType;
  description: string;
  categorie: string;
  sous_categorie: string;
  montant: number;
}

export interface Objective {
  id: number;
  nom: string;
  cible: number;
  actuel: number;
  date_cible: string;
  description: string;
  priorite: Priority;
  categorie: string;
  sous_categorie: string;
}

export interface Budget {
  categorie: string;
  budget: number;
}

export interface Categories {
  revenus: string[];
  depenses: string[];
  epargne: string[];
}

export interface RecurrentTransaction {
  id: number;
  description: string;
  type: TransactionType;
  categorie: string;
  sous_categorie: string;
  montant: number;
  jour: number;
  actif: boolean;
  dateDebut: string;
  dateFin: string | null;
}

export interface AlertConfig {
  emailEnabled: boolean;
  alertEmail: string;
  alertSeuils: {
    budget: number;
    objectif: number;
    tauxEpargneMin: number;
    depenseMax: number;
    soldeNegatif: boolean;
  };
}

export interface AppState {
  transactions: Transaction[];
  objectifs: Objective[];
  budgets: Budget[];
  categories: Categories;
  recurrentes: RecurrentTransaction[];
  currentYear: number;
  currentMonth: string;
  theme: 'dark' | 'light';
  alertConfig: AlertConfig;
}

export interface UserData {
  uid: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName: string;
  isActivated: boolean;
}

export interface ActivationRequest {
  id?: string;
  userId: string;
  email: string;
  userName: string;
  status: 'pending' | 'approved' | 'rejected';
  screenshotProvided: boolean;
  requestDate: Date;
}

export interface MonthData {
  revenus: { current: number; previous: number; variation: number };
  depenses: { current: number; previous: number; variation: number };
  epargne: { current: number; previous: number; variation: number };
  solde: { current: number; previous: number; variation: number };
}

export type SectionId =
  | 'dashboard'
  | 'transactions'
  | 'budgets'
  | 'objectifs'
  | 'calendrier'
  | 'rapports'
  | 'analyse'
  | 'parametres'
  | 'admin';
