import { useState, useMemo } from 'react';
import { Plus, Edit, Trash2, Lock } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { getFilteredTransactions, formatMoney } from '@/utils/helpers';
import ConfirmDialog from '@/components/ConfirmDialog';
import type { Notification } from '@/hooks/useNotification';

interface Props {
  filters: { year: string; month: string; category: string; type: string; search: string };
  isActivated: boolean;
  onNotify: (msg: string, type: Notification['type']) => void;
  onOpenGuide: () => void;
}

export default function Budgets({ filters, isActivated, onNotify, onOpenGuide }: Props) {
  const { state, addBudget, updateBudget, deleteBudget } = useApp();
  const depenses = useMemo(() => getFilteredTransactions(state.transactions, filters).filter(t => t.type === 'Dépense'), [state.transactions, filters]);

  const [editModal, setEditModal] = useState(false);
  const [editCat, setEditCat] = useState('');
  [editCat];
  const [editBudget, setEditBudget] = useState(0);
  const [editNewCat, setEditNewCat] = useState('');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleteCat, setDeleteCat] = useState('');
  const [addModal, setAddModal] = useState(false);
  const [newCat, setNewCat] = useState('');
  const [newBudget, setNewBudget] = useState('');

  const handleEdit = (cat: string, budget: number) => {
    if (!isActivated) { onNotify('Activation requise', 'warning'); onOpenGuide(); return; }
    setEditCat(cat);
    setEditNewCat(cat);
    setEditBudget(budget);
    setEditModal(true);
  };

  const handleDelete = (cat: string) => { setDeleteCat(cat); setConfirmOpen(true); };

  const handleAdd = () => {
    if (!isActivated) { onNotify('Activation requise', 'warning'); onOpenGuide(); return; }
    setNewCat(''); setNewBudget(''); setAddModal(true);
  };

  const confirmDelete = () => {
    deleteBudget(deleteCat);
    onNotify('Categorie supprimee', 'warning');
    setConfirmOpen(false);
  };

  const saveEdit = () => {
    if (!editNewCat.trim() || editBudget <= 0) { onNotify('Donnees invalides', 'danger'); return; }
    updateBudget(editCat, editNewCat.trim(), editBudget);
    onNotify('Budget modifie', 'success');
    setEditModal(false);
  };

  const saveAdd = () => {
    if (!newCat.trim() || !newBudget || parseFloat(newBudget) <= 0) { onNotify('Donnees invalides', 'danger'); return; }
    if (state.budgets.some(b => b.categorie.toLowerCase() === newCat.trim().toLowerCase())) {
      onNotify('Categorie existante', 'warning'); return;
    }
    addBudget(newCat.trim(), parseFloat(newBudget));
    onNotify('Categorie ajoutee', 'success');
    setAddModal(false);
  };

  const getProgressClass = (pct: number) => {
    if (pct > 100) return 'bg-red-500';
    if (pct > 80) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const getStatus = (pct: number) => {
    if (pct > 100) return <span className="text-red-400 text-xs">Depassement</span>;
    if (pct > 80) return <span className="text-amber-400 text-xs">Attention</span>;
    return <span className="text-emerald-400 text-xs">OK</span>;
  };

  return (
    <section>
      <div className="flex justify-between items-center mb-7">
        <div>
          <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
            Budgets Mensuels
          </h2>
          <p className="text-[13px] text-[var(--text-muted)] mt-1">Controlez vos depenses par categorie</p>
        </div>
        <button onClick={handleAdd}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                     flex items-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 hover:-translate-y-0.5 transition-all">
          <Plus className="w-4 h-4" /> Nouvelle categorie
        </button>
      </div>

      {/* Budget Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5 mb-7">
        {state.budgets.map(b => {
          const realise = depenses.filter(t => t.categorie === b.categorie).reduce((s, t) => s + t.montant, 0);
          const pct = b.budget > 0 ? (realise / b.budget * 100) : 0;
          return (
            <div key={b.categorie} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 relative overflow-hidden
                                            hover:-translate-y-1 hover:shadow-xl transition-all">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)]" />
              <div className="flex justify-between items-start mb-4">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">{b.categorie}</span>
                {isActivated ? (
                  <div className="flex gap-1">
                    <button onClick={() => handleEdit(b.categorie, b.budget)}
                      className="p-1 rounded-lg bg-[var(--bg)] border border-[var(--border)] hover:bg-[var(--border)] transition-all">
                      <Edit className="w-3 h-3 text-[var(--text-muted)]" />
                    </button>
                    <button onClick={() => handleDelete(b.categorie)}
                      className="p-1 rounded-lg bg-red-500/15 border border-red-500/30 hover:bg-red-500/25 transition-all">
                      <Trash2 className="w-3 h-3 text-red-400" />
                    </button>
                  </div>
                ) : <Lock className="w-3 h-3 text-amber-400" />}
              </div>
              <div className="text-lg font-bold text-[var(--text)] mb-3">{formatMoney(realise)} / {formatMoney(b.budget)}</div>
              <div className="h-2 bg-[var(--border)] rounded-full overflow-hidden mb-2">
                <div className={`h-full rounded-full transition-all duration-500 ${getProgressClass(pct)}`}
                  style={{ width: `${Math.min(pct, 100)}%` }} />
              </div>
              <div className="flex justify-between">
                <span className="text-xs text-[var(--text-muted)]">{pct.toFixed(1)}%</span>
                {getStatus(pct)}
              </div>
            </div>
          );
        })}
      </div>

      {/* Budget Table */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 overflow-x-auto">
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr className="border-b border-[var(--border)]">
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Categorie</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Budget</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Realise</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Restant</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Conso.</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Statut</th>
            </tr>
          </thead>
          <tbody>
            {state.budgets.map(b => {
              const realise = depenses.filter(t => t.categorie === b.categorie).reduce((s, t) => s + t.montant, 0);
              const pct = b.budget > 0 ? (realise / b.budget * 100) : 0;
              return (
                <tr key={b.categorie} className="border-b border-[var(--border)] hover:bg-[var(--primary)]/5 transition-colors">
                  <td className="py-3.5 px-3 text-[13px] font-semibold">{b.categorie}</td>
                  <td className="py-3.5 px-3 text-[13px]">{formatMoney(b.budget)}</td>
                  <td className="py-3.5 px-3 text-[13px] text-red-400">{formatMoney(realise)}</td>
                  <td className="py-3.5 px-3 text-[13px]">{formatMoney(b.budget - realise)}</td>
                  <td className="py-3.5 px-3 text-[13px]">{pct.toFixed(1)}%</td>
                  <td className="py-3.5 px-3">{getStatus(pct)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Edit Modal */}
      {editModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center" onClick={() => setEditModal(false)}>
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          <div className="relative bg-[var(--bg-card)] border border-[var(--border)] rounded-3xl w-[90%] max-w-[400px] p-7 animate-[modalIn_0.3s_ease]"
            onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-[var(--text)] mb-4">Modifier "{editCat}"</h3>
            <div className="mb-4">
              <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Nouveau nom</label>
              <input type="text" value={editNewCat} onChange={e => setEditNewCat(e.target.value)}
                className="w-full px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
            </div>
            <div className="mb-5">
              <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Budget mensuel</label>
              <input type="number" value={editBudget} onChange={e => setEditBudget(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setEditModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-sm font-semibold hover:bg-[var(--border)] transition-all">
                Annuler
              </button>
              <button onClick={saveEdit}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold hover:shadow-lg transition-all">
                Enregistrer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Modal */}
      {addModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center" onClick={() => setAddModal(false)}>
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
          <div className="relative bg-[var(--bg-card)] border border-[var(--border)] rounded-3xl w-[90%] max-w-[400px] p-7 animate-[modalIn_0.3s_ease]"
            onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-[var(--text)] mb-1">Nouvelle categorie</h3>
            <p className="text-xs text-[var(--text-muted)] mb-4">Disponible dans les transactions</p>
            <div className="mb-4">
              <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Nom</label>
              <input type="text" value={newCat} onChange={e => setNewCat(e.target.value)} placeholder="Ex: Restaurants"
                className="w-full px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
            </div>
            <div className="mb-5">
              <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Budget mensuel (MAD)</label>
              <input type="number" value={newBudget} onChange={e => setNewBudget(e.target.value)} placeholder="0"
                className="w-full px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setAddModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-sm font-semibold hover:bg-[var(--border)] transition-all">
                Annuler
              </button>
              <button onClick={saveAdd}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold hover:shadow-lg transition-all">
                Ajouter
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog open={confirmOpen} title="Supprimer la categorie ?"
        message={`La categorie "${deleteCat}" sera supprimee. Les transactions associees resteront.`} variant="danger"
        onConfirm={confirmDelete} onCancel={() => setConfirmOpen(false)} />
    </section>
  );
}
