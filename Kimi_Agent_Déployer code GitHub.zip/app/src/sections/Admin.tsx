import { useState } from 'react';
import { Shield, RefreshCw, CheckCircle, XCircle, Ban } from 'lucide-react';
import type { Notification } from '@/hooks/useNotification';

interface ActivationReq {
  id: string;
  userId: string;
  email: string;
  userName: string;
  status: string;
  requestDate: string;
}

interface ActivatedUser {
  id: string;
  fullName: string;
  email: string;
  activationDate: string;
}

interface Props {
  onNotify: (msg: string, type: Notification['type']) => void;
}

// Mock data for admin - in real app this would come from Firebase
const MOCK_PENDING: ActivationReq[] = [
  { id: '1', userId: 'u1', email: 'user1@example.com', userName: 'Ahmed Ben', status: 'pending', requestDate: '2026-06-15' },
  { id: '2', userId: 'u2', email: 'user2@example.com', userName: 'Sara Alaoui', status: 'pending', requestDate: '2026-06-16' },
];

const MOCK_ACTIVATED: ActivatedUser[] = [
  { id: 'a1', fullName: 'Karim Fassi', email: 'karim@example.com', activationDate: '2026-06-10' },
  { id: 'a2', fullName: 'Laila Moussaoui', email: 'laila@example.com', activationDate: '2026-06-12' },
];

export default function Admin({ onNotify }: Props) {
  const [pending, setPending] = useState<ActivationReq[]>(MOCK_PENDING);
  const [activated, setActivated] = useState<ActivatedUser[]>(MOCK_ACTIVATED);
  const [manualEmail, setManualEmail] = useState('');

  const handleActivate = (req: ActivationReq) => {
    if (!confirm(`Activer ${req.userName} (${req.email}) ?`)) return;
    setPending(prev => prev.filter(p => p.id !== req.id));
    setActivated(prev => [...prev, { id: req.userId, fullName: req.userName, email: req.email, activationDate: new Date().toISOString().split('T')[0] }]);
    onNotify(`${req.email} active !`, 'success');
  };

  const handleReject = (req: ActivationReq) => {
    if (!confirm(`Rejeter ${req.userName} ?`)) return;
    setPending(prev => prev.filter(p => p.id !== req.id));
    onNotify(`Demande de ${req.userName} rejetee`, 'warning');
  };

  const handleDeactivate = (user: ActivatedUser) => {
    if (!confirm(`Desactiver ${user.fullName} (${user.email}) ?`)) return;
    setActivated(prev => prev.filter(u => u.id !== user.id));
    onNotify(`${user.email} desactive`, 'warning');
  };

  const handleManualActivate = () => {
    if (!manualEmail.trim()) { onNotify('Email requis', 'danger'); return; }
    if (!activated.some(u => u.email === manualEmail.trim())) {
      setActivated(prev => [...prev, { id: Date.now().toString(), fullName: manualEmail.split('@')[0], email: manualEmail.trim(), activationDate: new Date().toISOString().split('T')[0] }]);
    }
    onNotify(`${manualEmail} active !`, 'success');
    setManualEmail('');
  };

  const handleRefresh = () => {
    onNotify('Listes rafraichies', 'success');
  };

  return (
    <section>
      <div className="mb-7">
        <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent flex items-center gap-3">
          <Shield className="w-7 h-7" /> Administration
        </h2>
        <p className="text-[13px] text-[var(--text-muted)] mt-1">Gestion des utilisateurs et activations</p>
      </div>

      {/* Pending Requests */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 mb-5">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-base font-semibold text-[var(--text)]">📋 Demandes d'activation en attente ({pending.length})</h3>
          <button onClick={handleRefresh}
            className="px-3 py-2 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-xs font-semibold
                       flex items-center gap-1.5 hover:bg-[var(--border)] transition-all">
            <RefreshCw className="w-3.5 h-3.5" /> Rafraichir
          </button>
        </div>

        {pending.length === 0 ? (
          <div className="text-center py-8 text-[var(--text-muted)] text-sm">✅ Aucune demande en attente</div>
        ) : (
          <div className="space-y-3">
            {pending.map(req => (
              <div key={req.id} className="bg-[var(--bg)] rounded-2xl p-5 border-l-4 border-amber-500 flex justify-between items-start flex-wrap gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[var(--primary)] to-[var(--secondary)] flex items-center justify-center text-white">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-bold text-sm">{req.userName}</div>
                    <div className="text-xs text-[var(--text-muted)]">{req.email}</div>
                    <div className="text-xs text-cyan-400 mt-0.5">📅 {req.requestDate}</div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleActivate(req)}
                    className="px-3 py-2 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-xs font-semibold
                               flex items-center gap-1.5 hover:bg-emerald-500/25 transition-all">
                    <CheckCircle className="w-3.5 h-3.5" /> Activer
                  </button>
                  <button onClick={() => handleReject(req)}
                    className="px-3 py-2 rounded-xl bg-red-500/15 text-red-400 border border-red-500/30 text-xs font-semibold
                               flex items-center gap-1.5 hover:bg-red-500/25 transition-all">
                    <XCircle className="w-3.5 h-3.5" /> Rejeter
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Activated Users */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 mb-5">
        <h3 className="text-base font-semibold text-[var(--text)] mb-4">✅ Utilisateurs actives ({activated.length})</h3>
        {activated.length === 0 ? (
          <div className="text-center py-8 text-[var(--text-muted)] text-sm">👥 Aucun utilisateur active</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse min-w-[500px]">
              <thead>
                <tr className="border-b border-[var(--border)]">
                  <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Nom</th>
                  <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Email</th>
                  <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Date</th>
                  <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Actions</th>
                </tr>
              </thead>
              <tbody>
                {activated.map(u => (
                  <tr key={u.id} className="border-b border-[var(--border)] hover:bg-[var(--primary)]/5 transition-colors">
                    <td className="py-3 px-3 text-sm font-semibold flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" /> {u.fullName}
                    </td>
                    <td className="py-3 px-3 text-sm">{u.email}</td>
                    <td className="py-3 px-3 text-sm text-[var(--text-muted)]">{u.activationDate}</td>
                    <td className="py-3 px-3">
                      <button onClick={() => handleDeactivate(u)}
                        className="px-3 py-1.5 rounded-lg bg-red-500/15 text-red-400 border border-red-500/30 text-xs
                                   hover:bg-red-500/25 transition-all flex items-center gap-1">
                        <Ban className="w-3 h-3" /> Desactiver
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manual Activation */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
        <h3 className="text-base font-semibold text-[var(--text)] mb-4">🔧 Activation manuelle</h3>
        <div className="flex gap-3">
          <input type="email" value={manualEmail} onChange={e => setManualEmail(e.target.value)}
            placeholder="utilisateur@email.com"
            className="flex-1 px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          <button onClick={handleManualActivate}
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                       flex items-center gap-2 hover:shadow-lg transition-all">
            <CheckCircle className="w-4 h-4" /> Activer
          </button>
        </div>
      </div>
    </section>
  );
}
