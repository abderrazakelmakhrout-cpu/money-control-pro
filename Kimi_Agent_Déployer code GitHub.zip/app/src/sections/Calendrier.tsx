import { useMemo } from 'react';
import { useApp } from '@/context/AppContext';
import { getFilteredTransactions, formatMoney } from '@/utils/helpers';

interface Props {
  filters: { year: string; month: string; category: string; type: string; search: string };
}

const DAYS = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

export default function Calendrier({ filters }: Props) {
  const { state } = useApp();
  const filtered = useMemo(() => getFilteredTransactions(state.transactions, filters), [state.transactions, filters]);

  const month = filters.month !== 'all' ? filters.month.split('-')[0] : state.currentMonth.split('-')[0];
  const year = filters.year !== 'all' ? parseInt(filters.year) : state.currentYear;

  const monthsList = ['janv', 'févr', 'mars', 'avr', 'mai', 'juin', 'juil', 'août', 'sept', 'oct', 'nov', 'déc'];
  const monthIndex = monthsList.indexOf(month);

  const firstDayOfMonth = new Date(year, monthIndex, 1).getDay();
  // Convert Sunday (0) to 6, Monday (1) to 0, etc.
  const startOffset = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

  const eventsByDay: Record<number, typeof filtered> = {};
  filtered.forEach(t => {
    const d = new Date(t.date);
    if (d.getMonth() === monthIndex && d.getFullYear() === year) {
      const day = d.getDate();
      if (!eventsByDay[day]) eventsByDay[day] = [];
      eventsByDay[day].push(t);
    }
  });

  return (
    <section>
      <div className="mb-7">
        <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
          Calendrier Financier
        </h2>
        <p className="text-[13px] text-[var(--text-muted)] mt-1">Visualisation des transactions</p>
      </div>

      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
        <div className="text-center mb-5">
          <h3 className="text-lg font-semibold text-[var(--text)] capitalize">{month} {year}</h3>
        </div>
        <div className="grid grid-cols-7 gap-2">
          {DAYS.map(d => (
            <div key={d} className="text-center text-xs font-bold text-[var(--primary)] py-2">{d}</div>
          ))}
          {/* Empty cells for offset */}
          {Array.from({ length: startOffset }, (_, i) => (
            <div key={`empty-${i}`} className="min-h-[100px]" />
          ))}
          {/* Days */}
          {Array.from({ length: daysInMonth }, (_, i) => {
            const day = i + 1;
            const events = eventsByDay[day] || [];
            const isToday = new Date().getDate() === day && new Date().getMonth() === monthIndex && new Date().getFullYear() === year;
            return (
              <div key={day}
                className={`bg-[var(--bg)] border border-[var(--border)] rounded-xl p-2 min-h-[100px] transition-all
                           hover:scale-[1.02] hover:border-[var(--primary)] ${isToday ? 'ring-2 ring-[var(--primary)]' : ''}`}>
                <div className="font-bold text-xs text-[var(--primary)] mb-1">{day}</div>
                {events.slice(0, 3).map((e, idx) => (
                  <div key={idx} className="text-[10px] px-1.5 py-0.5 rounded-md mt-1 bg-[var(--primary)]/20 truncate">
                    {e.type === 'Revenu' ? '💰' : '💸'} {formatMoney(e.montant)}
                  </div>
                ))}
                {events.length > 3 && (
                  <div className="text-[10px] text-[var(--text-muted)] mt-1">+{events.length - 3} de plus</div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
