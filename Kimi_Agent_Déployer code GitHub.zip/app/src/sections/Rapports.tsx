import { useMemo } from 'react';
import { Chart as ChartJS, registerables } from 'chart.js';
import { Line } from 'react-chartjs-2';
import { Printer } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { getFilteredTransactions, getPreviousMonthData, formatMoney } from '@/utils/helpers';

ChartJS.register(...registerables);

interface Props {
  filters: { year: string; month: string; category: string; type: string; search: string };
}

export default function Rapports({ filters }: Props) {
  const { state } = useApp();
  const filtered = useMemo(() => getFilteredTransactions(state.transactions, filters), [state.transactions, filters]);
  const prevData = useMemo(() => getPreviousMonthData(state.transactions, state.currentYear, state.currentMonth), [state.transactions, state.currentYear, state.currentMonth]);

  const revenus = filtered.filter(t => t.type === 'Revenu').reduce((s, t) => s + t.montant, 0);
  const depenses = filtered.filter(t => t.type === 'Dépense').reduce((s, t) => s + t.montant, 0);
  const epargne = filtered.filter(t => t.type === 'Épargne').reduce((s, t) => s + t.montant, 0);
  const balance = revenus - depenses - epargne;
  const tauxEpargne = revenus > 0 ? (epargne / revenus * 100).toFixed(1) : '0';
  const tauxDepenses = revenus > 0 ? (depenses / revenus * 100).toFixed(1) : '0';

  // Top 5
  const depParCat: Record<string, number> = {};
  filtered.filter(t => t.type === 'Dépense').forEach(t => { depParCat[t.categorie] = (depParCat[t.categorie] || 0) + t.montant; });
  const top5Dep = Object.entries(depParCat).sort((a, b) => b[1] - a[1]).slice(0, 5);

  const revParCat: Record<string, number> = {};
  filtered.filter(t => t.type === 'Revenu').forEach(t => { revParCat[t.categorie] = (revParCat[t.categorie] || 0) + t.montant; });
  const top5Rev = Object.entries(revParCat).sort((a, b) => b[1] - a[1]).slice(0, 5);

  // Category report
  const catReport: Record<string, { revenus: number; depenses: number; epargne: number }> = {};
  filtered.forEach(t => {
    if (!catReport[t.categorie]) catReport[t.categorie] = { revenus: 0, depenses: 0, epargne: 0 };
    if (t.type === 'Revenu') catReport[t.categorie].revenus += t.montant;
    if (t.type === 'Dépense') catReport[t.categorie].depenses += t.montant;
    if (t.type === 'Épargne') catReport[t.categorie].epargne += t.montant;
  });

  // Monthly evolution
  const months = [...new Set(state.transactions.map(t => t.mois))].sort();
  const revByMonth = months.map(m => state.transactions.filter(t => t.mois === m && t.type === 'Revenu').reduce((s, t) => s + t.montant, 0));
  const depByMonth = months.map(m => state.transactions.filter(t => t.mois === m && t.type === 'Dépense').reduce((s, t) => s + t.montant, 0));
  const balByMonth = months.map((_m, i) => revByMonth[i] - depByMonth[i]);

  const soldeMoyen = balByMonth.reduce((a, b) => a + b, 0) / (balByMonth.length || 1);
  const bestIdx = balByMonth.length > 0 ? balByMonth.reduce((maxI, _val, i, arr) => arr[i] > arr[maxI] ? i : maxI, 0) : 0;
  const worstIdx = balByMonth.length > 0 ? balByMonth.reduce((minI, _val, i, arr) => arr[i] < arr[minI] ? i : minI, 0) : 0;

  const chartData = {
    labels: months,
    datasets: [
      { label: 'Revenus', data: revByMonth, borderColor: '#10b981', backgroundColor: 'transparent', tension: 0.4 },
      { label: 'Depenses', data: depByMonth, borderColor: '#ef4444', backgroundColor: 'transparent', tension: 0.4 },
      { label: 'Balance', data: balByMonth, borderColor: '#6366f1', backgroundColor: 'transparent', tension: 0.4 },
    ]
  };

  const totalGen = revenus + depenses + epargne;

  return (
    <section>
      <div className="flex justify-between items-center mb-7 flex-wrap gap-4">
        <div>
          <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
            Rapports Financiers
          </h2>
          <p className="text-[13px] text-[var(--text-muted)] mt-1">Analyses detaillees</p>
        </div>
        <button onClick={() => window.print()}
          className="px-5 py-2.5 rounded-xl bg-[var(--bg-card)] border border-[var(--border)] text-[var(--text)] text-sm font-semibold
                     flex items-center gap-2 hover:bg-[var(--border)] transition-all">
          <Printer className="w-4 h-4" /> Imprimer
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-7">
        {[
          { label: 'Revenus', value: `+${formatMoney(revenus)}`, color: 'text-emerald-400', sub: `${prevData.revenus.variation >= 0 ? '↑' : '↓'} ${Math.abs(prevData.revenus.variation)}%` },
          { label: 'Depenses', value: `-${formatMoney(depenses)}`, color: 'text-red-400', sub: `${prevData.depenses.variation <= 0 ? '↓' : '↑'} ${Math.abs(prevData.depenses.variation)}%` },
          { label: 'Epargne', value: formatMoney(epargne), color: 'text-cyan-400', sub: `Taux: ${tauxEpargne}%` },
          { label: 'Balance', value: `${balance >= 0 ? '+' : ''}${formatMoney(balance)}`, color: balance >= 0 ? 'text-emerald-400' : 'text-red-400', sub: `${prevData.solde.variation >= 0 ? '↑' : '↓'} ${Math.abs(prevData.solde.variation)}%` },
        ].map((s, i) => (
          <div key={i} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[14px] p-5 text-center">
            <div className={`text-2xl font-extrabold ${s.color}`}>{s.value}</div>
            <div className="text-[11px] text-[var(--text-muted)] mt-1.5">{s.label}</div>
            <div className="text-[11px] mt-1">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-7">
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <h3 className="text-base font-semibold text-[var(--text)] mb-4">Evolution</h3>
          <div className="h-[280px]">
            <Line data={chartData} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: 'var(--text-light)', font: { size: 11 } } } }, scales: { x: { ticks: { color: 'var(--text-muted)', font: { size: 10 } } }, y: { ticks: { color: 'var(--text-muted)', font: { size: 10 } } } } }} />
          </div>
        </div>
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <h3 className="text-base font-semibold text-[var(--text)] mb-4">Top 5 Depenses</h3>
          <div className="space-y-1">
            {top5Dep.map(([cat, mnt], i) => (
              <div key={cat} className="flex justify-between items-center py-2.5 border-b border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-lg bg-red-500/15 flex items-center justify-center text-xs font-bold text-red-400">{i + 1}</span>
                  <span className="font-semibold text-sm">{cat}</span>
                </div>
                <span className="font-bold text-red-400 text-sm">-{formatMoney(mnt)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <h3 className="text-base font-semibold text-[var(--text)] mb-4">Top 5 Revenus</h3>
          <div className="space-y-1">
            {top5Rev.map(([cat, mnt], i) => (
              <div key={cat} className="flex justify-between items-center py-2.5 border-b border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/15 flex items-center justify-center text-xs font-bold text-emerald-400">{i + 1}</span>
                  <span className="font-semibold text-sm">{cat}</span>
                </div>
                <span className="font-bold text-emerald-400 text-sm">+{formatMoney(mnt)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <h3 className="text-base font-semibold text-[var(--text)] mb-4">Indicateurs Cles</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[var(--bg)] rounded-xl p-3 text-center">
              <div className="text-[11px] text-[var(--text-muted)]">Taux epargne</div>
              <div className="text-xl font-extrabold text-cyan-400">{tauxEpargne}%</div>
            </div>
            <div className="bg-[var(--bg)] rounded-xl p-3 text-center">
              <div className="text-[11px] text-[var(--text-muted)]">Taux depenses</div>
              <div className="text-xl font-extrabold text-amber-400">{tauxDepenses}%</div>
            </div>
            <div className="bg-[var(--bg)] rounded-xl p-3 text-center">
              <div className="text-[11px] text-[var(--text-muted)]">Balance moyenne</div>
              <div className={`text-lg font-extrabold ${soldeMoyen >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{formatMoney(soldeMoyen)}</div>
            </div>
            <div className="bg-[var(--bg)] rounded-xl p-3 text-center">
              <div className="text-[11px] text-[var(--text-muted)]">Meilleur/Pire</div>
              <div className="text-sm font-bold">
                <span className="text-emerald-400">{months[bestIdx] || '-'}</span> / <span className="text-red-400">{months[worstIdx] || '-'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Category Table */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 mb-5 overflow-x-auto">
        <h3 className="text-base font-semibold text-[var(--text)] mb-4">Analyse par categorie</h3>
        <table className="w-full border-collapse min-w-[500px]">
          <thead>
            <tr className="border-b border-[var(--border)]">
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Categorie</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Revenus</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Depenses</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Epargne</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Solde</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">%</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(catReport).map(([cat, data]) => {
              const solde = data.revenus - data.depenses - data.epargne;
              const pct = totalGen > 0 ? ((data.revenus + data.depenses + data.epargne) / totalGen * 100).toFixed(1) : '0';
              return (
                <tr key={cat} className="border-b border-[var(--border)] hover:bg-[var(--primary)]/5 transition-colors">
                  <td className="py-3 px-3 text-sm font-semibold">{cat}</td>
                  <td className="py-3 px-3 text-sm text-emerald-400">+{formatMoney(data.revenus)}</td>
                  <td className="py-3 px-3 text-sm text-red-400">-{formatMoney(data.depenses)}</td>
                  <td className="py-3 px-3 text-sm text-cyan-400">{formatMoney(data.epargne)}</td>
                  <td className={`py-3 px-3 text-sm font-semibold ${solde >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{solde >= 0 ? '+' : ''}{formatMoney(solde)}</td>
                  <td className="py-3 px-3 text-sm text-[var(--text-muted)]">{pct}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Monthly Table */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 overflow-x-auto">
        <h3 className="text-base font-semibold text-[var(--text)] mb-4">Bilan mensuel</h3>
        <table className="w-full border-collapse min-w-[500px]">
          <thead>
            <tr className="border-b border-[var(--border)]">
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Mois</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Revenus</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Depenses</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Balance</th>
              <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Evolution</th>
            </tr>
          </thead>
          <tbody>
            {months.map((m, i) => {
              const evol = i > 0 && balByMonth[i - 1] !== 0 ? ((balByMonth[i] - balByMonth[i - 1]) / Math.abs(balByMonth[i - 1]) * 100).toFixed(1) : '0';
              return (
                <tr key={m} className="border-b border-[var(--border)] hover:bg-[var(--primary)]/5 transition-colors">
                  <td className="py-3 px-3 text-sm font-semibold">{m}</td>
                  <td className="py-3 px-3 text-sm text-emerald-400">+{formatMoney(revByMonth[i])}</td>
                  <td className="py-3 px-3 text-sm text-red-400">-{formatMoney(depByMonth[i])}</td>
                  <td className={`py-3 px-3 text-sm font-semibold ${balByMonth[i] >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{balByMonth[i] >= 0 ? '+' : ''}{formatMoney(balByMonth[i])}</td>
                  <td className={`py-3 px-3 text-sm ${parseFloat(evol) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{evol >= '0' ? '↑' : '↓'} {Math.abs(parseFloat(evol))}%</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
