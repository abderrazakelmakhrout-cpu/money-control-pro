import { useState } from 'react';
import { Play, Calendar, Info, Plus, Edit, Trash2 } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import RecurrentModal from '@/components/RecurrentModal';
import ConfirmDialog from '@/components/ConfirmDialog';
import type { RecurrentTransaction } from '@/types';
import type { Notification } from '@/hooks/useNotification';

interface Props {
  isActivated: boolean;
  onNotify: (msg: string, type: Notification['type']) => void;
  onOpenGuide: () => void;
}

export default function Parametres({ isActivated, onNotify, onOpenGuide }: Props) {
  const { state, addRecurrent, updateRecurrent, deleteRecurrent, toggleRecurrent, executeRecurrents, dispatch } = useApp();
  const [recModalOpen, setRecModalOpen] = useState(false);
  const [editRec, setEditRec] = useState<RecurrentTransaction | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [currency, setCurrency] = useState('MAD');
  const [budgetAlert, setBudgetAlert] = useState('80');
  const [objAlert, setObjAlert] = useState('90');

  const handleAddRec = () => {
    if (!isActivated) { onNotify('Activation requise', 'warning'); onOpenGuide(); return; }
    setEditRec(null); setRecModalOpen(true);
  };

  const handleEditRec = (r: RecurrentTransaction) => {
    if (!isActivated) { onNotify('Activation requise', 'warning'); onOpenGuide(); return; }
    setEditRec(r); setRecModalOpen(true);
  };

  const handleSaveRec = (data: Omit<RecurrentTransaction, 'id'>) => {
    if (editRec) {
      updateRecurrent(editRec.id, data);
      onNotify('Recurrente modifiee', 'success');
    } else {
      addRecurrent(data);
      onNotify('Recurrente ajoutee', 'success');
    }
    setRecModalOpen(false);
  };

  const handleDeleteRec = (id: number) => { setDeleteId(id); setConfirmOpen(true); };

  const confirmDelete = () => {
    if (deleteId !== null) { deleteRecurrent(deleteId); onNotify('Supprimee', 'warning'); }
    setConfirmOpen(false); setDeleteId(null);
  };

  const handleExecute = () => {
    executeRecurrents();
    onNotify('Transactions recurrentes executees', 'success');
  };

  const handleReset = () => {
    dispatch({ type: 'RESET_DATA' });
    setConfirmReset(false);
    onNotify('Donnees reinitialisees', 'success');
  };

  const handleSaveSettings = () => {
    dispatch({ type: 'SET_DATA', payload: { alertConfig: { ...state.alertConfig, alertSeuils: { ...state.alertConfig.alertSeuils, budget: parseInt(budgetAlert), objectif: parseInt(objAlert) } } } });
    onNotify('Parametres sauvegardes', 'success');
  };

  const badgeClass = (type: string) => {
    if (type === 'Revenu') return 'bg-emerald-500/15 text-emerald-400';
    if (type === 'Dépense') return 'bg-red-500/15 text-red-400';
    return 'bg-cyan-500/15 text-cyan-400';
  };

  return (
    <section>
      <div className="mb-7">
        <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
          Parametres
        </h2>
        <p className="text-[13px] text-[var(--text-muted)] mt-1">Personnalisation et transactions recurrentes</p>
      </div>

      {/* General Settings */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 mb-5">
        <h3 className="text-base font-semibold text-[var(--text)] mb-4">⚙️ Configuration</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Devise</label>
            <select value={currency} onChange={e => setCurrency(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]">
              <option>MAD</option><option>EUR</option><option>USD</option>
            </select>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Alerte Budget (%)</label>
            <input type="number" value={budgetAlert} onChange={e => setBudgetAlert(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Alerte Objectif (%)</label>
            <input type="number" value={objAlert} onChange={e => setObjAlert(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          </div>
        </div>
        <div className="flex gap-3 flex-wrap">
          <button onClick={handleSaveSettings}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                       hover:shadow-lg transition-all">
            💾 Sauvegarder
          </button>
          <button onClick={() => setConfirmReset(true)}
            className="px-5 py-2.5 rounded-xl bg-red-500/15 text-red-400 border border-red-500/30 text-sm font-semibold
                       hover:bg-red-500/25 transition-all">
            ↩ Reinitialiser
          </button>
        </div>
      </div>

      {/* Recurrent Transactions */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
        <div className="flex justify-between items-center mb-4 flex-wrap gap-3">
          <h3 className="text-base font-semibold text-[var(--text)]">🔄 Transactions recurrentes mensuelles</h3>
          <button onClick={handleAddRec}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                       flex items-center gap-2 hover:shadow-lg transition-all">
            <Plus className="w-4 h-4" /> Ajouter
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse min-w-[600px]">
            <thead>
              <tr className="border-b border-[var(--border)]">
                <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Description</th>
                <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Type</th>
                <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Categorie</th>
                <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Montant</th>
                <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Jour</th>
                <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Statut</th>
                <th className="text-left py-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Actions</th>
              </tr>
            </thead>
            <tbody>
              {state.recurrentes.map(r => (
                <tr key={r.id} className="border-b border-[var(--border)] hover:bg-[var(--primary)]/5 transition-colors">
                  <td className="py-3 px-3 text-sm font-semibold">{r.description}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${badgeClass(r.type)}`}>{r.type}</span>
                  </td>
                  <td className="py-3 px-3 text-sm">{r.categorie}</td>
                  <td className={`py-3 px-3 text-sm font-semibold ${r.type === 'Revenu' ? 'text-emerald-400' : r.type === 'Dépense' ? 'text-red-400' : 'text-cyan-400'}`}>
                    {r.type === 'Dépense' ? '-' : '+'}{formatMoney(r.montant)}
                  </td>
                  <td className="py-3 px-3 text-sm">Jour {r.jour}</td>
                  <td className="py-3 px-3">
                    <button onClick={() => toggleRecurrent(r.id)}
                      className={`px-2 py-1 rounded-full text-[11px] font-semibold transition-all ${r.actif ? 'bg-emerald-500/15 text-emerald-400' : 'bg-red-500/15 text-red-400'}`}>
                      {r.actif ? '✅ Actif' : '⏸️ Inactif'}
                    </button>
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex gap-1.5">
                      <button onClick={() => handleEditRec(r)}
                        className="p-1.5 rounded-lg bg-[var(--bg)] border border-[var(--border)] hover:bg-[var(--border)] transition-all">
                        <Edit className="w-3.5 h-3.5 text-[var(--text-muted)]" />
                      </button>
                      <button onClick={() => handleDeleteRec(r.id)}
                        className="p-1.5 rounded-lg bg-red-500/15 border border-red-500/30 hover:bg-red-500/25 transition-all">
                        <Trash2 className="w-3.5 h-3.5 text-red-400" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {state.recurrentes.length === 0 && (
          <div className="text-center py-8 text-[var(--text-muted)] text-sm">
            <Calendar className="w-8 h-8 mx-auto mb-3 opacity-50" />
            <p>Aucune transaction recurrente</p>
          </div>
        )}

        <div className="mt-4 flex gap-3 flex-wrap items-center">
          <button onClick={handleExecute}
            className="px-4 py-2.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-sm font-semibold
                       flex items-center gap-2 hover:bg-emerald-500/25 transition-all">
            <Play className="w-4 h-4" /> Executer maintenant
          </button>
          <span className="text-xs text-[var(--text-muted)] flex items-center gap-1">
            <Info className="w-3 h-3" /> Les transactions sont ajoutees automatiquement
          </span>
        </div>
      </div>

      <RecurrentModal open={recModalOpen} onClose={() => setRecModalOpen(false)} onSave={handleSaveRec} editData={editRec} />
      <ConfirmDialog open={confirmOpen} title="Supprimer ?" message="Cette transaction recurrente sera supprimee." variant="danger"
        onConfirm={confirmDelete} onCancel={() => setConfirmOpen(false)} />
      <ConfirmDialog open={confirmReset} title="Reinitialiser toutes les donnees ?"
        message="⚠️ Cette action est irreversible. Toutes vos transactions, budgets et objectifs seront remis aux valeurs par defaut." variant="danger"
        onConfirm={handleReset} onCancel={() => setConfirmReset(false)} />
    </section>
  );
}

function formatMoney(n: number): string {
  return n.toLocaleString('fr-FR') + ' MAD';
}
