import { useMemo } from 'react';
import { Percent, Scale, TrendingUp } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { getFilteredTransactions, formatMoney } from '@/utils/helpers';

interface Props {
  filters: { year: string; month: string; category: string; type: string; search: string };
}

const cardIcons = [
  <Percent className="w-5 h-5" />, <Scale className="w-5 h-5" />, <TrendingUp className="w-5 h-5" />
];

export default function Analyse({ filters }: Props) {
  const { state } = useApp();
  const filtered = useMemo(() => getFilteredTransactions(state.transactions, filters), [state.transactions, filters]);

  const revenus = filtered.filter(t => t.type === 'Revenu').reduce((s, t) => s + t.montant, 0);
  const depenses = filtered.filter(t => t.type === 'Dépense').reduce((s, t) => s + t.montant, 0);
  const epargne = filtered.filter(t => t.type === 'Épargne').reduce((s, t) => s + t.montant, 0);
  const tauxEpargne = revenus > 0 ? (epargne / revenus * 100).toFixed(1) : '0';
  const ratioDep = revenus > 0 ? (depenses / revenus * 100).toFixed(1) : '0';
  const previsionAnnuelle = (revenus - depenses) * 12;

  const kpiData = [
    { label: "Taux d'epargne", value: `${tauxEpargne}%`, sub: 'Objectif: >20%', icon: cardIcons[0] },
    { label: 'Ratio Depenses/Revenus', value: `${ratioDep}%`, sub: 'Ideal: <50%', icon: cardIcons[1] },
    { label: 'Prevision annuelle', value: formatMoney(previsionAnnuelle), sub: 'Epargne projetee', icon: cardIcons[2] },
  ];

  // Additional analysis
  const depParCat: Record<string, number> = {};
  filtered.filter(t => t.type === 'Dépense').forEach(t => { depParCat[t.categorie] = (depParCat[t.categorie] || 0) + t.montant; });
  const topDepense = Object.entries(depParCat).sort((a, b) => b[1] - a[1])[0];

  const revParCat: Record<string, number> = {};
  filtered.filter(t => t.type === 'Revenu').forEach(t => { revParCat[t.categorie] = (revParCat[t.categorie] || 0) + t.montant; });
  const topRevenu = Object.entries(revParCat).sort((a, b) => b[1] - a[1])[0];

  const moyenneDepense = filtered.filter(t => t.type === 'Dépense').length > 0
    ? depenses / filtered.filter(t => t.type === 'Dépense').length : 0;

  return (
    <section>
      <div className="mb-7">
        <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
          Analyse Financiere
        </h2>
        <p className="text-[13px] text-[var(--text-muted)] mt-1">Indicateurs avances</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5 mb-7">
        {kpiData.map((kpi, i) => (
          <div key={i} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 relative overflow-hidden
                                  hover:-translate-y-1 hover:shadow-xl transition-all duration-200">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)]" />
            <div className="w-12 h-12 rounded-[14px] flex items-center justify-center text-xl mb-4
                            bg-[var(--primary)]/15 text-[var(--primary)]">
              {kpi.icon}
            </div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] mb-2">{kpi.label}</div>
            <div className="text-[28px] font-bold text-[var(--text)]">{kpi.value}</div>
            <div className="text-[11px] text-[var(--text-muted)] mt-1.5">{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* Detailed Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <h3 className="text-base font-semibold text-[var(--text)] mb-4">📊 Resume</h3>
          <div className="space-y-3">
            <div className="flex justify-between py-2 border-b border-[var(--border)]">
              <span className="text-sm text-[var(--text-muted)]">Revenus totaux</span>
              <span className="text-sm font-semibold text-emerald-400">{formatMoney(revenus)}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border)]">
              <span className="text-sm text-[var(--text-muted)]">Depenses totales</span>
              <span className="text-sm font-semibold text-red-400">{formatMoney(depenses)}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border)]">
              <span className="text-sm text-[var(--text-muted)]">Epargne</span>
              <span className="text-sm font-semibold text-cyan-400">{formatMoney(epargne)}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border)]">
              <span className="text-sm text-[var(--text-muted)]">Balance nette</span>
              <span className={`text-sm font-semibold ${revenus - depenses - epargne >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {formatMoney(revenus - depenses - epargne)}
              </span>
            </div>
            <div className="flex justify-between py-2 border-b border-[var(--border)]">
              <span className="text-sm text-[var(--text-muted)]">Nombre de transactions</span>
              <span className="text-sm font-semibold">{filtered.length}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-sm text-[var(--text-muted)]">Depense moyenne</span>
              <span className="text-sm font-semibold">{formatMoney(moyenneDepense)}</span>
            </div>
          </div>
        </div>

        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <h3 className="text-base font-semibold text-[var(--text)] mb-4">🏆 Top Categories</h3>
          <div className="space-y-3">
            {topRevenu && (
              <div className="flex justify-between py-2 border-b border-[var(--border)]">
                <span className="text-sm text-[var(--text-muted)]">💰 Plus grand revenu</span>
                <span className="text-sm font-semibold text-emerald-400">{topRevenu[0]} ({formatMoney(topRevenu[1])})</span>
              </div>
            )}
            {topDepense && (
              <div className="flex justify-between py-2 border-b border-[var(--border)]">
                <span className="text-sm text-[var(--text-muted)]">💸 Plus grande depense</span>
                <span className="text-sm font-semibold text-red-400">{topDepense[0]} ({formatMoney(topDepense[1])})</span>
              </div>
            )}
            <div className="flex justify-between py-2 border-b border-[var(--border)]">
              <span className="text-sm text-[var(--text-muted)]">📈 Taux d'epargne</span>
              <span className={`text-sm font-semibold ${parseFloat(tauxEpargne) >= 20 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {tauxEpargne}%
              </span>
            </div>
            <div className="flex justify-between py-2">
              <span className="text-sm text-[var(--text-muted)]">💡 Recommandation</span>
              <span className="text-sm font-semibold text-[var(--text)]">
                {parseFloat(tauxEpargne) >= 20 ? 'Excellent!' : parseFloat(tauxEpargne) >= 10 ? 'Bien' : 'A ameliorer'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
