import { useMemo } from 'react';
import { Chart as ChartJS, registerables } from 'chart.js';
import { Doughnut, Line, Bar } from 'react-chartjs-2';
import { Wallet, ArrowUp, ArrowDown, PiggyBank, BarChart3, Percent } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { getFilteredTransactions, getPreviousMonthData, formatMoney } from '@/utils/helpers';
ChartJS.register(...registerables);

interface Props {
  filters: { year: string; month: string; category: string; type: string; search: string };
  onNavigate: (section: string) => void;
  onOpenTxModal: () => void;
}

const chartColors = {
  primary: ['#6366f1', '#ec4899', '#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#84cc16'],
  revenus: ['#10b981', '#06b6d4', '#f59e0b', '#6366f1'],
};

const cardIcons = [
  <Wallet className="w-5 h-5" />, <ArrowUp className="w-5 h-5" />, <ArrowDown className="w-5 h-5" />,
  <PiggyBank className="w-5 h-5" />, <BarChart3 className="w-5 h-5" />, <Percent className="w-5 h-5" />
];

export default function Dashboard({ filters, onNavigate, onOpenTxModal }: Props) {
  const { state } = useApp();
  const filtered = useMemo(() => getFilteredTransactions(state.transactions, filters), [state.transactions, filters]);
  const prevData = useMemo(() => getPreviousMonthData(state.transactions, state.currentYear, state.currentMonth), [state.transactions, state.currentYear, state.currentMonth]);

  const revenus = filtered.filter(t => t.type === 'Revenu').reduce((s, t) => s + t.montant, 0);
  const depenses = filtered.filter(t => t.type === 'Dépense').reduce((s, t) => s + t.montant, 0);
  const epargne = filtered.filter(t => t.type === 'Épargne').reduce((s, t) => s + t.montant, 0);
  const totalBudget = state.budgets.reduce((s, b) => s + b.budget, 0);
  const budgetConsomme = depenses;
  const pctBudget = totalBudget > 0 ? (budgetConsomme / totalBudget * 100).toFixed(1) : '0';

  let totalSoldeCumule = 0;
  [...state.transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .forEach(t => { if (t.type === 'Revenu') totalSoldeCumule += t.montant; else totalSoldeCumule -= t.montant; });

  const tauxEpargne = revenus > 0 ? ((epargne / revenus) * 100).toFixed(1) : '0';
  const tauxDepenses = revenus > 0 ? ((depenses / revenus) * 100).toFixed(1) : '0';

  const kpiData = [
    { label: 'SOLDE TOTAL', value: formatMoney(totalSoldeCumule), sub: `${prevData.solde.variation >= 0 ? '↑' : '↓'} ${Math.abs(prevData.solde.variation)}%`, subClass: prevData.solde.variation >= 0 ? 'text-emerald-400' : 'text-red-400' },
    { label: 'REVENUS', value: formatMoney(revenus), sub: `${prevData.revenus.variation >= 0 ? '↑' : '↓'} ${Math.abs(prevData.revenus.variation)}%`, subClass: prevData.revenus.variation >= 0 ? 'text-emerald-400' : 'text-red-400' },
    { label: 'DEPENSES', value: formatMoney(depenses), sub: `${prevData.depenses.variation <= 0 ? '↓' : '↑'} ${Math.abs(prevData.depenses.variation)}%`, subClass: prevData.depenses.variation <= 0 ? 'text-emerald-400' : 'text-red-400' },
    { label: 'EPARGNE', value: formatMoney(epargne), sub: `${prevData.epargne.variation >= 0 ? '↑' : '↓'} ${Math.abs(prevData.epargne.variation)}%`, subClass: prevData.epargne.variation >= 0 ? 'text-emerald-400' : 'text-red-400' },
    { label: 'BUDGET CONSOMME', value: `${pctBudget}%`, sub: `${formatMoney(budgetConsomme)} / ${formatMoney(totalBudget)}`, subClass: 'text-[var(--text-muted)]' },
    { label: 'TAUX D\'EPARGNE', value: `${tauxEpargne}%`, sub: `${tauxDepenses}% de dépenses`, subClass: 'text-[var(--text-muted)]' },
  ];

  // Expenses by category
  const depParCat: Record<string, number> = {};
  filtered.filter(t => t.type === 'Dépense').forEach(t => { depParCat[t.categorie] = (depParCat[t.categorie] || 0) + t.montant; });
  const expenseChartData = {
    labels: Object.keys(depParCat),
    datasets: [{ data: Object.values(depParCat), backgroundColor: chartColors.primary, borderWidth: 0 }]
  };

  // Income by category
  const revParCat: Record<string, number> = {};
  filtered.filter(t => t.type === 'Revenu').forEach(t => { revParCat[t.categorie] = (revParCat[t.categorie] || 0) + t.montant; });
  const incomeChartData = {
    labels: Object.keys(revParCat),
    datasets: [{ data: Object.values(revParCat), backgroundColor: chartColors.revenus, borderWidth: 0 }]
  };

  // Monthly evolution
  const months = [...new Set(state.transactions.map(t => t.mois))].sort();
  const revMois = months.map(m => state.transactions.filter(t => t.mois === m && t.type === 'Revenu').reduce((s, t) => s + t.montant, 0));
  const depMois = months.map(m => state.transactions.filter(t => t.mois === m && t.type === 'Dépense').reduce((s, t) => s + t.montant, 0));
  const evolutionData = {
    labels: months,
    datasets: [
      { label: 'Revenus', data: revMois, borderColor: '#10b981', backgroundColor: 'transparent', tension: 0.4 },
      { label: 'Dépenses', data: depMois, borderColor: '#ef4444', backgroundColor: 'transparent', tension: 0.4 },
    ]
  };

  // Budget vs Real
  const budgetVsReal = state.budgets.map(b => ({
    categorie: b.categorie,
    budget: b.budget,
    realise: filtered.filter(t => t.type === 'Dépense' && t.categorie === b.categorie).reduce((s, t) => s + t.montant, 0)
  }));
  const budgetChartData = {
    labels: budgetVsReal.map(b => b.categorie),
    datasets: [
      { label: 'Budget', data: budgetVsReal.map(b => b.budget), backgroundColor: '#06b6d4', borderRadius: 6 },
      { label: 'Realise', data: budgetVsReal.map(b => b.realise), backgroundColor: '#ec4899', borderRadius: 6 },
    ]
  };

  // Alerts
  const alerts: { type: string; msg: string }[] = [];
  if (parseFloat(pctBudget) > 100) alerts.push({ type: 'danger', msg: `⚠️ Depassement budget : ${pctBudget}%` });
  else if (parseFloat(pctBudget) > 80) alerts.push({ type: 'warning', msg: `⚠️ Budget a ${pctBudget}%` });
  state.objectifs.forEach(o => {
    const pct = (o.actuel / o.cible) * 100;
    if (pct > 85 && pct < 100) alerts.push({ type: 'warning', msg: `🎯 "${o.nom}" a ${pct.toFixed(1)}%` });
  });

  const chartOptions = { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: 'var(--text-light)', font: { size: 11 } } } } };
  const lineOptions = { ...chartOptions, scales: { x: { ticks: { color: 'var(--text-muted)', font: { size: 10 } } }, y: { ticks: { color: 'var(--text-muted)', font: { size: 10 } } } } };
  const barOptions = { ...chartOptions, scales: { x: { ticks: { color: 'var(--text-muted)', font: { size: 10 } } }, y: { ticks: { color: 'var(--text-muted)', font: { size: 10 } } } } };

  return (
    <section>
      {/* Header */}
      <div className="flex justify-between items-center mb-7 flex-wrap gap-4">
        <div>
          <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
            Tableau de Bord
          </h2>
          <p className="text-[13px] text-[var(--text-muted)] mt-1">Vue d'ensemble de vos finances personnelles</p>
        </div>
        <div className="flex gap-2.5 flex-wrap">
          <button onClick={onOpenTxModal}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                       flex items-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 hover:-translate-y-0.5 transition-all">
            + Transaction
          </button>
          <button onClick={() => onNavigate('objectifs')}
            className="px-5 py-2.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-sm font-semibold
                       flex items-center gap-2 hover:bg-emerald-500/25 transition-all">
            🐷 Epargne Objectif
          </button>
        </div>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2 mb-4">
          {alerts.map((a, i) => (
            <div key={i} className={`flex items-center gap-3 px-5 py-3.5 rounded-xl text-sm border-l-4 bg-[var(--bg-card)]
              ${a.type === 'danger' ? 'border-l-red-500 text-red-400' : 'border-l-amber-500 text-amber-400'}`}>
              {a.msg}
            </div>
          ))}
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5 mb-7">
        {kpiData.map((kpi, i) => (
          <div key={i} className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 relative overflow-hidden
                                  hover:-translate-y-1 hover:shadow-xl transition-all duration-200 group">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)]" />
            <div className="w-12 h-12 rounded-[14px] flex items-center justify-center text-xl mb-4
                            bg-[var(--primary)]/15 text-[var(--primary)]">
              {cardIcons[i]}
            </div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] mb-2">{kpi.label}</div>
            <div className="text-[28px] font-bold text-[var(--text)]">{kpi.value}</div>
            <div className={`text-[11px] mt-1.5 ${kpi.subClass}`}>{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-7">
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-base font-semibold text-[var(--text)]">Repartition des Depenses</h3>
          </div>
          <div className="h-[280px]"><Doughnut data={expenseChartData} options={chartOptions} /></div>
        </div>
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-base font-semibold text-[var(--text)]">Repartition des Revenus</h3>
          </div>
          <div className="h-[280px]"><Doughnut data={incomeChartData} options={chartOptions} /></div>
        </div>
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-base font-semibold text-[var(--text)]">Evolution Mensuelle</h3>
          </div>
          <div className="h-[280px]"><Line data={evolutionData} options={lineOptions} /></div>
        </div>
        <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-base font-semibold text-[var(--text)]">Budget vs Realise</h3>
          </div>
          <div className="h-[280px]"><Bar data={budgetChartData} options={barOptions} /></div>
        </div>
      </div>
    </section>
  );
}
