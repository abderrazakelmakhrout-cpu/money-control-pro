import { useState, useMemo } from 'react';
import { Plus, Edit, Trash2, PiggyBank } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { formatMoney } from '@/utils/helpers';
import ObjectiveModal from '@/components/ObjectiveModal';
import ConfirmDialog from '@/components/ConfirmDialog';
import type { Objective } from '@/types';
import type { Notification } from '@/hooks/useNotification';

interface Props {
  isActivated: boolean;
  onNotify: (msg: string, type: Notification['type']) => void;
  onOpenGuide: () => void;
}

export default function ObjectifsSection({ isActivated, onNotify, onOpenGuide }: Props) {
  const { state, addObjective, updateObjective, deleteObjective } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [editObj, setEditObj] = useState<Objective | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  // Sync objectives with epargne transactions
  const objectifs = useMemo(() => {
    const epargneTxs = state.transactions.filter(t => t.type === 'Épargne');
    return state.objectifs.map(obj => {
      const total = epargneTxs
        .filter(t => t.sous_categorie === obj.nom || t.description.toLowerCase().includes(obj.nom.toLowerCase()))
        .reduce((s, t) => s + t.montant, 0);
      return { ...obj, actuel: total };
    });
  }, [state.objectifs, state.transactions]);

  const handleAdd = () => {
    if (!isActivated) { onNotify('Activation requise', 'warning'); onOpenGuide(); return; }
    setEditObj(null); setModalOpen(true);
  };

  const handleEdit = (obj: Objective) => {
    if (!isActivated) { onNotify('Activation requise', 'warning'); onOpenGuide(); return; }
    setEditObj(obj); setModalOpen(true);
  };

  const handleSave = (data: Omit<Objective, 'id'>) => {
    if (editObj) {
      updateObjective(editObj.id, data);
      onNotify('Objectif modifie', 'success');
    } else {
      addObjective(data);
      onNotify('Objectif cree', 'success');
    }
    setModalOpen(false);
  };

  const handleDelete = (id: number) => { setDeleteId(id); setConfirmOpen(true); };

  const confirmDelete = () => {
    if (deleteId !== null) { deleteObjective(deleteId); onNotify('Objectif supprime', 'warning'); }
    setConfirmOpen(false); setDeleteId(null);
  };

  const handleEpargne = () => {
    if (!isActivated) { onNotify('Activation requise', 'warning'); onOpenGuide(); return; }
    if (objectifs.length === 0) { onNotify('Creez d\'abord un objectif', 'info'); handleAdd(); return; }
    const noms = objectifs.map(o => o.nom).join(', ');
    const nom = prompt(`Choisir l'objectif:\n${noms}`, objectifs[0]?.nom || '');
    if (!nom) return;
    if (!objectifs.some(o => o.nom === nom)) {
      if (!confirm(`L'objectif "${nom}" n'existe pas. Le creer ?`)) return;
      const cible = prompt('Montant cible:', '10000');
      if (!cible || isNaN(parseFloat(cible))) return;
      const date = prompt('Date cible (AAAA-MM-JJ):', new Date().toISOString().split('T')[0]);
      if (!date) return;
      addObjective({ nom, cible: parseFloat(cible), actuel: 0, date_cible: date, description: 'Cree automatiquement', priorite: 'Moyenne', categorie: 'Épargne', sous_categorie: nom });
      onNotify('Objectif cree', 'success');
    }
  };

  const getBorderClass = (p: string) => {
    if (p === 'Haute') return 'before:bg-gradient-to-r before:from-red-500 before:to-amber-500';
    if (p === 'Moyenne') return 'before:bg-gradient-to-r before:from-amber-500 before:to-cyan-500';
    return 'before:bg-gradient-to-r before:from-emerald-500 before:to-[var(--primary)]';
  };

  return (
    <section>
      <div className="flex justify-between items-center mb-7 flex-wrap gap-4">
        <div>
          <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
            Objectifs d'Epargne
          </h2>
          <p className="text-[13px] text-[var(--text-muted)] mt-1">Suivez la progression de vos projets</p>
        </div>
        <div className="flex gap-2.5 flex-wrap">
          <button onClick={handleAdd}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                       flex items-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 hover:-translate-y-0.5 transition-all">
            <Plus className="w-4 h-4" /> Nouvel objectif
          </button>
          <button onClick={handleEpargne}
            className="px-5 py-2.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-sm font-semibold
                       flex items-center gap-2 hover:bg-emerald-500/25 transition-all">
            <PiggyBank className="w-4 h-4" /> Epargne + Objectif
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {objectifs.map(o => {
          const pct = o.cible > 0 ? (o.actuel / o.cible * 100) : 0;
          const joursRestants = Math.ceil((new Date(o.date_cible).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
          return (
            <div key={o.id} className={`bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 relative overflow-hidden
                                       hover:-translate-y-1 hover:shadow-xl transition-all ${getBorderClass(o.priorite)}`}>
              <div className="absolute top-0 left-0 right-0 h-1 before:content-[''] before:absolute before:inset-0" />
              <div className="flex justify-between items-start mb-4 flex-wrap gap-3">
                <div>
                  <div className="text-lg font-bold text-[var(--text)] flex items-center gap-2">
                    {o.nom} {o.actuel >= o.cible && <span className="text-emerald-400 text-sm">🎉</span>}
                  </div>
                  <div className="text-[11px] text-[var(--text-muted)] mt-1">{o.description}</div>
                  <div className="text-[11px] text-[var(--text-muted)] mt-1">
                    📅 {o.date_cible} · {joursRestants > 0 ? `${joursRestants} jours restants` : '⏰ Delai depasse'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-[var(--text)]">{formatMoney(o.actuel)}</div>
                  <div className="text-[11px] text-[var(--text-muted)]">/{formatMoney(o.cible)}</div>
                </div>
              </div>
              <div className="text-2xl font-bold text-[var(--primary)] mb-3">{pct.toFixed(1)}%</div>
              <div className="h-2 bg-[var(--border)] rounded-full overflow-hidden mb-4">
                <div className={`h-full rounded-full transition-all duration-500 ${pct >= 100 ? 'bg-emerald-500' : pct > 80 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                  style={{ width: `${Math.min(pct, 100)}%` }} />
              </div>
              <div className="flex justify-end gap-2">
                <button onClick={() => handleEdit(o)}
                  className="px-3 py-2 rounded-lg bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-xs hover:bg-[var(--border)] transition-all">
                  <Edit className="w-3.5 h-3.5 inline mr-1" /> Modifier
                </button>
                <button onClick={() => handleDelete(o.id)}
                  className="px-3 py-2 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 text-xs hover:bg-red-500/25 transition-all">
                  <Trash2 className="w-3.5 h-3.5 inline mr-1" /> Supprimer
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {objectifs.length === 0 && (
        <div className="text-center py-16 text-[var(--text-muted)]">
          <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>Aucun objectif. Creez votre premier objectif d'epargne !</p>
        </div>
      )}

      <ObjectiveModal open={modalOpen} onClose={() => setModalOpen(false)} onSave={handleSave} editData={editObj} />
      <ConfirmDialog open={confirmOpen} title="Supprimer l'objectif ?"
        message="Cette action est irreversible." variant="danger"
        onConfirm={confirmDelete} onCancel={() => setConfirmOpen(false)} />
    </section>
  );
}

function Target({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" />
    </svg>
  );
}
