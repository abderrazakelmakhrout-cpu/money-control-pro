import { useState, useMemo } from 'react';
import { Plus, Edit, Trash2, FileSpreadsheet, FileText, FileDown } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { getFilteredTransactions, formatMoney, formatDate } from '@/utils/helpers';
import TransactionModal from '@/components/TransactionModal';
import ConfirmDialog from '@/components/ConfirmDialog';
import type { Transaction } from '@/types';
import type { Notification } from '@/hooks/useNotification';

interface Props {
  filters: { year: string; month: string; category: string; type: string; search: string };
  isActivated: boolean;
  onNotify: (msg: string, type: Notification['type']) => void;
  onOpenGuide: () => void;
}

export default function Transactions({ filters, isActivated, onNotify, onOpenGuide }: Props) {
  const { state, deleteTransaction } = useApp();
  const filtered = useMemo(() => getFilteredTransactions(state.transactions, filters), [state.transactions, filters]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editTx, setEditTx] = useState<Transaction | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const handleAdd = () => {
    if (!isActivated) { onNotify('Activez votre compte pour ajouter des transactions', 'warning'); onOpenGuide(); return; }
    setEditTx(null);
    setModalOpen(true);
  };

  const handleEdit = (tx: Transaction) => {
    if (!isActivated) { onNotify('Activez votre compte pour modifier des transactions', 'warning'); onOpenGuide(); return; }
    setEditTx(tx);
    setModalOpen(true);
  };

  const handleDelete = (id: number) => { setDeleteId(id); setConfirmOpen(true); };

  const confirmDelete = () => {
    if (deleteId !== null) { deleteTransaction(deleteId); onNotify('Transaction supprimee', 'success'); }
    setConfirmOpen(false);
    setDeleteId(null);
  };

  // Export functions
  const exportCSV = () => {
    let csv = "Date,Type,Description,Categorie,Sous-categorie,Montant\n";
    filtered.forEach(t => csv += `${t.date},${t.type},"${t.description}",${t.categorie},${t.sous_categorie},${t.montant}\n`);
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `transactions_${state.currentMonth}.csv`;
    a.click();
    onNotify('Export CSV reussi', 'success');
  };

  const exportPDF = () => {
    // @ts-ignore
    const { jsPDF } = window.jspdf;
    if (!jsPDF) { onNotify('jsPDF non charge', 'warning'); return; }
    const doc = new jsPDF();
    doc.setFontSize(16); doc.text('Rapport Money Control Pro', 20, 20);
    doc.setFontSize(12); doc.text(`Periode: ${state.currentMonth} ${state.currentYear}`, 20, 30);
    let y = 50;
    filtered.slice(0, 30).forEach(t => {
      if (y > 270) { doc.addPage(); y = 20; }
      doc.text(`${t.date} - ${t.description}: ${t.montant} MAD`, 20, y); y += 8;
    });
    doc.save(`Rapport_${state.currentMonth}.pdf`);
    onNotify('Export PDF reussi', 'success');
  };

  const exportExcel = () => {
    // @ts-ignore
    const XLSX = window.XLSX;
    if (!XLSX) { onNotify('XLSX non charge', 'warning'); return; }
    const ws = XLSX.utils.json_to_sheet(filtered);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Transactions');
    XLSX.writeFile(wb, `rapport_${state.currentMonth}.xlsx`);
    onNotify('Export Excel reussi', 'success');
  };

  const badgeClass = (type: string) => {
    if (type === 'Revenu') return 'bg-emerald-500/15 text-emerald-400';
    if (type === 'Dépense') return 'bg-red-500/15 text-red-400';
    return 'bg-cyan-500/15 text-cyan-400';
  };

  return (
    <section>
      <div className="flex justify-between items-center mb-7 flex-wrap gap-4">
        <div>
          <h2 className="text-[28px] font-bold bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] bg-clip-text text-transparent">
            Transactions
          </h2>
          <p className="text-[13px] text-[var(--text-muted)] mt-1">Gérez vos revenus, dépenses et épargne</p>
        </div>
        <button onClick={handleAdd}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                     flex items-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 hover:-translate-y-0.5 transition-all">
          <Plus className="w-4 h-4" /> Ajouter
        </button>
      </div>

      {/* Table */}
      <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-[20px] p-5 mb-5 overflow-x-auto">
        <div className="flex justify-between items-center mb-5 flex-wrap gap-3">
          <h3 className="text-lg font-semibold text-[var(--text)]">Historique des transactions</h3>
          <div className="flex gap-2">
            <button onClick={exportCSV} className="px-3 py-2 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-xs font-semibold
                               flex items-center gap-1.5 hover:bg-[var(--border)] transition-all">
              <FileSpreadsheet className="w-3.5 h-3.5" /> CSV
            </button>
            <button onClick={exportPDF} className="px-3 py-2 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-xs font-semibold
                               flex items-center gap-1.5 hover:bg-[var(--border)] transition-all">
              <FileText className="w-3.5 h-3.5" /> PDF
            </button>
            <button onClick={exportExcel} className="px-3 py-2 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-xs font-semibold
                               flex items-center gap-1.5 hover:bg-[var(--border)] transition-all">
              <FileDown className="w-3.5 h-3.5" /> Excel
            </button>
          </div>
        </div>
        <table className="w-full border-collapse min-w-[600px]">
          <thead>
            <tr className="border-b border-[var(--border)]">
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Date</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Type</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Description</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Categorie</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Sous-cat.</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Montant</th>
              <th className="text-left py-3.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(t => (
              <tr key={t.id} className="border-b border-[var(--border)] hover:bg-[var(--primary)]/5 transition-colors">
                <td className="py-3.5 px-3 text-[13px]">{formatDate(t.date)}</td>
                <td className="py-3.5 px-3">
                  <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${badgeClass(t.type)}`}>{t.type}</span>
                </td>
                <td className="py-3.5 px-3 text-[13px]">{t.description}</td>
                <td className="py-3.5 px-3 text-[13px]">{t.categorie}</td>
                <td className="py-3.5 px-3 text-[13px] text-[var(--text-muted)]">{t.sous_categorie || '-'}</td>
                <td className={`py-3.5 px-3 text-[13px] font-semibold ${t.type === 'Revenu' ? 'text-emerald-400' : 'text-red-400'}`}>
                  {t.type === 'Dépense' ? '-' : '+'}{formatMoney(t.montant)}
                </td>
                <td className="py-3.5 px-3">
                  <div className="flex gap-1.5">
                    <button onClick={() => handleEdit(t)}
                      className="px-2 py-1.5 rounded-lg bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-xs
                                 hover:bg-[var(--border)] transition-all">
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => handleDelete(t.id)}
                      className="px-2 py-1.5 rounded-lg bg-red-500/15 border border-red-500/30 text-red-400 text-xs
                                 hover:bg-red-500/25 transition-all">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-10 text-[var(--text-muted)] text-sm">Aucune transaction trouvee</div>
        )}
      </div>

      <TransactionModal open={modalOpen} onClose={() => setModalOpen(false)} editData={editTx} />
      <ConfirmDialog open={confirmOpen} title="Supprimer la transaction ?"
        message="Cette action est irreversible." variant="danger"
        onConfirm={confirmDelete} onCancel={() => setConfirmOpen(false)} />
    </section>
  );
}
