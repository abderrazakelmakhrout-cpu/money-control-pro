import { useState } from 'react';
import { BarChart3, LogIn, UserPlus, Mail, ArrowLeft } from 'lucide-react';
import type { NotifType } from '@/hooks/useNotification';

interface Props {
  onLogin: (email: string, password: string) => Promise<void>;
  onRegister: (firstName: string, lastName: string, email: string, password: string) => Promise<void>;
  onResetPassword: (email: string) => Promise<void>;
  onNotify: (msg: string, type: NotifType) => void;
  loading: boolean;
}

type FormMode = 'login' | 'register' | 'reset';

export default function LoginPage({ onLogin, onRegister, onResetPassword, onNotify, loading }: Props) {
  const [mode, setMode] = useState<FormMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const resetFields = () => {
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setFirstName('');
    setLastName('');
    setErrors({});
  };

  const validateEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  const handleLogin = async () => {
    const errs: Record<string, string> = {};
    if (!email) errs.email = 'Email requis';
    else if (!validateEmail(email)) errs.email = 'Email invalide';
    if (!password) errs.password = 'Mot de passe requis';
    else if (password.length < 6) errs.password = 'Minimum 6 caractères';
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    try { await onLogin(email, password); onNotify('Connexion réussie !', 'success'); }
    catch (err: any) {
      const msg = err.code === 'auth/user-not-found' ? 'Aucun compte trouvé' :
        err.code === 'auth/wrong-password' ? 'Mot de passe incorrect' :
          err.code === 'auth/too-many-requests' ? 'Trop de tentatives' : err.message;
      onNotify(msg, 'danger');
    }
  };

  const handleRegister = async () => {
    const errs: Record<string, string> = {};
    if (!firstName.trim()) errs.firstName = 'Prénom requis';
    if (!lastName.trim()) errs.lastName = 'Nom requis';
    if (!email) errs.email = 'Email requis';
    else if (!validateEmail(email)) errs.email = 'Email invalide';
    if (!password) errs.password = 'Mot de passe requis';
    else if (password.length < 6) errs.password = 'Minimum 6 caractères';
    if (password !== confirmPassword) errs.confirm = 'Mots de passe différents';
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    try { await onRegister(firstName, lastName, email, password); onNotify('Compte créé !', 'success'); }
    catch (err: any) {
      const msg = err.code === 'auth/email-already-in-use' ? 'Email déjà utilisé' :
        err.code === 'auth/weak-password' ? 'Mot de passe trop faible' : err.message;
      onNotify(msg, 'danger');
    }
  };

  const handleReset = async () => {
    if (!email || !validateEmail(email)) { setErrors({ email: 'Email valide requis' }); return; }
    try { await onResetPassword(email); onNotify('Email envoyé !', 'success'); setMode('login'); }
    catch (err: any) { onNotify(err.message, 'danger'); }
  };

  const inputClass = (hasError: boolean) =>
    `w-full px-4 py-3.5 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm
     focus:outline-none focus:border-[var(--primary)] transition-colors
     ${hasError ? 'border-red-500' : 'border-[var(--border)]'}`;

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
      <div className="w-full max-w-[450px]">
        <div className="bg-[var(--bg-card)] rounded-[28px] p-10 shadow-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-[75px] h-[75px] rounded-[22px] flex items-center justify-center mx-auto mb-5"
              style={{ background: 'linear-gradient(135deg, #667eea, #764ba2)' }}>
              <BarChart3 className="w-9 h-9 text-white" />
            </div>
            <h1 className="text-[28px] font-extrabold text-[var(--text)]">Money Control Pro</h1>
            <p className="text-sm text-[var(--text-muted)] mt-2">Gestion financière professionnelle</p>
          </div>

          {/* Login Form */}
          {mode === 'login' && (
            <div className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Email</label>
                <input type="email" value={email} onChange={e => { setEmail(e.target.value); setErrors({}); }}
                  placeholder="exemple@email.com" className={inputClass(!!errors.email)} />
                {errors.email && <span className="text-red-400 text-xs mt-1">{errors.email}</span>}
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Mot de passe</label>
                <input type="password" value={password} onChange={e => { setPassword(e.target.value); setErrors({}); }}
                  onKeyDown={e => e.key === 'Enter' && handleLogin()}
                  placeholder="••••••••" className={inputClass(!!errors.password)} />
                {errors.password && <span className="text-red-400 text-xs mt-1">{errors.password}</span>}
              </div>
              <button onClick={handleLogin} disabled={loading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white font-semibold
                           flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 transition-all disabled:opacity-50">
                {loading ? '⏳ Connexion...' : <><LogIn className="w-4 h-4" /> Se connecter</>}
              </button>
              <div className="text-center text-sm mt-4 space-y-2">
                <button onClick={() => { setMode('register'); resetFields(); }}
                  className="text-[var(--primary)] hover:underline font-medium flex items-center gap-1 mx-auto">
                  <UserPlus className="w-4 h-4" /> Créer un compte
                </button>
                <button onClick={() => { setMode('reset'); resetFields(); }}
                  className="text-[var(--text-muted)] hover:text-[var(--text)] text-xs flex items-center gap-1 mx-auto">
                  <Mail className="w-3 h-3" /> Mot de passe oublié ?
                </button>
              </div>
            </div>
          )}

          {/* Register Form */}
          {mode === 'register' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Prénom</label>
                  <input type="text" value={firstName} onChange={e => { setFirstName(e.target.value); setErrors({}); }}
                    placeholder="Jean" className={inputClass(!!errors.firstName)} />
                  {errors.firstName && <span className="text-red-400 text-xs">{errors.firstName}</span>}
                </div>
                <div>
                  <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Nom</label>
                  <input type="text" value={lastName} onChange={e => { setLastName(e.target.value); setErrors({}); }}
                    placeholder="Dupont" className={inputClass(!!errors.lastName)} />
                  {errors.lastName && <span className="text-red-400 text-xs">{errors.lastName}</span>}
                </div>
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Email</label>
                <input type="email" value={email} onChange={e => { setEmail(e.target.value); setErrors({}); }}
                  placeholder="exemple@email.com" className={inputClass(!!errors.email)} />
                {errors.email && <span className="text-red-400 text-xs">{errors.email}</span>}
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Mot de passe</label>
                <input type="password" value={password} onChange={e => { setPassword(e.target.value); setErrors({}); }}
                  placeholder="••••••••" className={inputClass(!!errors.password)} />
                {errors.password && <span className="text-red-400 text-xs">{errors.password}</span>}
              </div>
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Confirmer</label>
                <input type="password" value={confirmPassword} onChange={e => { setConfirmPassword(e.target.value); setErrors({}); }}
                  placeholder="••••••••" className={inputClass(!!errors.confirm)} />
                {errors.confirm && <span className="text-red-400 text-xs">{errors.confirm}</span>}
              </div>
              <button onClick={handleRegister} disabled={loading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white font-semibold
                           flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 transition-all disabled:opacity-50">
                {loading ? '⏳ Création...' : <><UserPlus className="w-4 h-4" /> Créer un compte</>}
              </button>
              <button onClick={() => { setMode('login'); resetFields(); }}
                className="w-full text-center text-sm text-[var(--text-muted)] hover:text-[var(--text)] flex items-center gap-1 justify-center">
                <ArrowLeft className="w-3 h-3" /> Déjà un compte ? Se connecter
              </button>
            </div>
          )}

          {/* Reset Form */}
          {mode === 'reset' && (
            <div className="space-y-4">
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-2">Email</label>
                <input type="email" value={email} onChange={e => { setEmail(e.target.value); setErrors({}); }}
                  placeholder="exemple@email.com" className={inputClass(!!errors.email)} />
                {errors.email && <span className="text-red-400 text-xs">{errors.email}</span>}
              </div>
              <button onClick={handleReset} disabled={loading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white font-semibold
                           flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 transition-all disabled:opacity-50">
                {loading ? '⏳ Envoi...' : <><Mail className="w-4 h-4" /> Envoyer le lien</>}
              </button>
              <button onClick={() => { setMode('login'); resetFields(); }}
                className="w-full text-center text-sm text-[var(--text-muted)] hover:text-[var(--text)] flex items-center gap-1 justify-center">
                <ArrowLeft className="w-3 h-3" /> Retour à la connexion
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
