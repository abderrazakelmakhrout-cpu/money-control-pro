import { MONTHS_LIST } from './defaults';
import type { Transaction, MonthData } from '@/types';

export const formatMoney = (n: number): string => n.toLocaleString('fr-FR') + ' MAD';
export const formatDate = (d: string): string => new Date(d).toLocaleDateString('fr-FR');

export function getFilteredTransactions(
  transactions: Transaction[],
  filters: { year: string; month: string; category: string; type: string; search: string }
): Transaction[] {
  let filtered = [...transactions];
  if (filters.year && filters.year !== 'all') filtered = filtered.filter(t => t.annee === parseInt(filters.year));
  if (filters.month && filters.month !== 'all') filtered = filtered.filter(t => t.mois === filters.month);
  if (filters.category && filters.category !== 'all') filtered = filtered.filter(t => t.categorie === filters.category);
  if (filters.type && filters.type !== 'all') filtered = filtered.filter(t => t.type === filters.type);
  if (filters.search) {
    const q = filters.search.toLowerCase();
    filtered = filtered.filter(t => t.description.toLowerCase().includes(q) || t.categorie.toLowerCase().includes(q));
  }
  return filtered;
}

export function getPreviousMonthData(
  transactions: Transaction[],
  currentYear: number,
  currentMonth: string
): MonthData {
  const currentMonthObj = new Date(currentYear, MONTHS_LIST.indexOf(currentMonth.split('-')[0]), 1);
  const prevMonthObj = new Date(currentMonthObj);
  prevMonthObj.setMonth(prevMonthObj.getMonth() - 1);
  const prevMonthName = MONTHS_LIST[prevMonthObj.getMonth()];
  const prevMonth = `${prevMonthName}-${prevMonthObj.getFullYear()}`;
  const prevYear = prevMonthObj.getFullYear();

  const prevTransactions = transactions.filter(t => t.mois === prevMonth && t.annee === prevYear);
  const currentFiltered = transactions.filter(t => t.mois === currentMonth && t.annee === currentYear);

  const sum = (arr: Transaction[], type: string) => arr.filter(t => t.type === type).reduce((s, t) => s + t.montant, 0);

  const currentRevenus = sum(currentFiltered, 'Revenu');
  const currentDepenses = sum(currentFiltered, 'Dépense');
  const currentEpargne = sum(currentFiltered, 'Épargne');
  const currentSolde = currentRevenus - currentDepenses - currentEpargne;

  const prevRevenus = sum(prevTransactions, 'Revenu');
  const prevDepenses = sum(prevTransactions, 'Dépense');
  const prevEpargne = sum(prevTransactions, 'Épargne');
  const prevSolde = prevRevenus - prevDepenses - prevEpargne;

  const calcVar = (c: number, p: number): number => p === 0 ? (c > 0 ? 100 : 0) : parseFloat(((c - p) / p * 100).toFixed(1));

  return {
    revenus: { current: currentRevenus, previous: prevRevenus, variation: calcVar(currentRevenus, prevRevenus) },
    depenses: { current: currentDepenses, previous: prevDepenses, variation: calcVar(currentDepenses, prevDepenses) },
    epargne: { current: currentEpargne, previous: prevEpargne, variation: calcVar(currentEpargne, prevEpargne) },
    solde: { current: currentSolde, previous: prevSolde, variation: calcVar(currentSolde, prevSolde) }
  };
}

export function generateUniqueId(): number {
  return Date.now() + Math.floor(Math.random() * 1000);
}

export function getMonthKey(date: Date): string {
  return `${MONTHS_LIST[date.getMonth()]}-${date.getFullYear()}`;
}

export function getYearOptions(transactions: Transaction[]): number[] {
  const years = [...new Set(transactions.map(t => t.annee))].sort((a, b) => b - a);
  return years.length ? years : [new Date().getFullYear()];
}

export function escapeHtml(str: string): string {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
