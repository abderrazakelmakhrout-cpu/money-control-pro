import type { Transaction, Objective, Budget, Categories, RecurrentTransaction } from '@/types';

export const DEFAULT_TRANSACTIONS: Transaction[] = [
  { id: 1, date: "2026-05-01", mois: "mai-2026", annee: 2026, type: "Revenu", description: "Salaire mai", categorie: "Salaire", sous_categorie: "Mensuel", montant: 8500 },
  { id: 2, date: "2026-05-05", mois: "mai-2026", annee: 2026, type: "Dépense", description: "Loyer", categorie: "Logement", sous_categorie: "Loyer", montant: 3500 },
  { id: 3, date: "2026-05-10", mois: "mai-2026", annee: 2026, type: "Revenu", description: "Freelance", categorie: "Freelance", sous_categorie: "Consulting", montant: 2500 },
  { id: 4, date: "2026-05-15", mois: "mai-2026", annee: 2026, type: "Dépense", description: "Courses", categorie: "Alimentation", sous_categorie: "Supermarché", montant: 1200 },
  { id: 5, date: "2026-05-20", mois: "mai-2026", annee: 2026, type: "Épargne", description: "Épargne voyage", categorie: "Épargne", sous_categorie: "Voyage Japon", montant: 1000 },
  { id: 6, date: "2026-04-10", mois: "avr-2026", annee: 2026, type: "Revenu", description: "Salaire avril", categorie: "Salaire", sous_categorie: "Mensuel", montant: 8200 },
  { id: 7, date: "2026-04-15", mois: "avr-2026", annee: 2026, type: "Dépense", description: "Loyer avril", categorie: "Logement", sous_categorie: "Loyer", montant: 3500 },
  { id: 8, date: "2026-04-20", mois: "avr-2026", annee: 2026, type: "Dépense", description: "Courses avril", categorie: "Alimentation", sous_categorie: "Supermarché", montant: 1100 },
  { id: 9, date: "2026-03-10", mois: "mars-2026", annee: 2026, type: "Revenu", description: "Salaire mars", categorie: "Salaire", sous_categorie: "Mensuel", montant: 8200 },
  { id: 10, date: "2026-03-15", mois: "mars-2026", annee: 2026, type: "Dépense", description: "Loyer mars", categorie: "Logement", sous_categorie: "Loyer", montant: 3500 }
];

export const DEFAULT_OBJECTIFS: Objective[] = [
  { id: 1, nom: "Voyage Japon", cible: 15000, actuel: 6500, date_cible: "2026-12-31", description: "Voyage de rêve", priorite: "Haute", categorie: "Épargne", sous_categorie: "Voyage Japon" },
  { id: 2, nom: "Achat Voiture", cible: 80000, actuel: 12500, date_cible: "2027-06-30", description: "Voiture familiale", priorite: "Moyenne", categorie: "Épargne", sous_categorie: "Achat Voiture" },
  { id: 3, nom: "Fonds Urgence", cible: 20000, actuel: 15000, date_cible: "2026-12-31", description: "Sécurité financière", priorite: "Haute", categorie: "Épargne", sous_categorie: "Fonds Urgence" }
];

export const DEFAULT_BUDGETS: Budget[] = [
  { categorie: "Alimentation", budget: 2000 },
  { categorie: "Logement", budget: 4000 },
  { categorie: "Transport", budget: 1000 },
  { categorie: "Loisirs", budget: 800 },
  { categorie: "Shopping", budget: 700 },
  { categorie: "Santé", budget: 500 }
];

export const DEFAULT_CATEGORIES: Categories = {
  revenus: ["Salaire", "Freelance", "Investissement", "Autre Revenu"],
  depenses: ["Alimentation", "Logement", "Transport", "Loisirs", "Shopping", "Santé", "Éducation", "Factures"],
  epargne: ["Voyage", "Voiture", "Urgence", "Investissement", "Projet"]
};

export const DEFAULT_TRANSACTIONS_RECURRENTES: RecurrentTransaction[] = [
  { id: 1, description: "Salaire mensuel", type: "Revenu", categorie: "Salaire", sous_categorie: "Mensuel", montant: 8500, jour: 1, actif: true, dateDebut: "2026-01-01", dateFin: null },
  { id: 2, description: "Loyer", type: "Dépense", categorie: "Logement", sous_categorie: "Loyer", montant: 3500, jour: 5, actif: true, dateDebut: "2026-01-01", dateFin: null },
  { id: 3, description: "Épargne mensuelle", type: "Épargne", categorie: "Épargne", sous_categorie: "Fonds Urgence", montant: 1000, jour: 20, actif: true, dateDebut: "2026-01-01", dateFin: null }
];

export const MONTHS_LIST = ['janv', 'févr', 'mars', 'avr', 'mai', 'juin', 'juil', 'août', 'sept', 'oct', 'nov', 'déc'];
