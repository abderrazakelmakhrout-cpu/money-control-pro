import { useState, useCallback } from 'react';

export type NotifType = 'success' | 'danger' | 'warning' | 'info';

export interface Notification {
  id: number;
  message: string;
  type: NotifType;
}

export function useNotification() {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const show = useCallback((message: string, type: NotifType = 'info') => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    const notif: Notification = { id, message, type };
    setNotifications(prev => [...prev, notif]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  }, []);

  const remove = useCallback((id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  return { notifications, show, remove };
}
