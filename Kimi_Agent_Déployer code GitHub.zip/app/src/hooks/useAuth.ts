import { useState, useEffect, useCallback } from 'react';
import {
  onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword,
  updateProfile, signOut, sendPasswordResetEmail, type User
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '@/config/firebase';
import type { UserData } from '@/types';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const docSnap = await getDoc(doc(db, 'users', u.uid));
        if (docSnap.exists()) {
          const data = docSnap.data() as UserData;
          setUserData(data);
          setIsAdmin(data.isActivated === true);
        } else {
          setUserData({
            uid: u.uid,
            email: u.email || '',
            firstName: u.displayName?.split(' ')[0] || '',
            lastName: u.displayName?.split(' ')[1] || '',
            fullName: u.displayName || u.email?.split('@')[0] || '',
            isActivated: false
          });
        }
      } else {
        setUserData(null);
        setIsAdmin(false);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const result = await signInWithEmailAndPassword(auth, email, password);
    return result.user;
  }, []);

  const register = useCallback(async (firstName: string, lastName: string, email: string, password: string) => {
    const result = await createUserWithEmailAndPassword(auth, email, password);
    const fullName = `${firstName} ${lastName}`;
    await updateProfile(result.user, { displayName: fullName });

    const userData: UserData = {
      uid: result.user.uid,
      email,
      firstName,
      lastName,
      fullName,
      isActivated: false
    };

    await setDoc(doc(db, 'users', result.user.uid), {
      ...userData,
      createdAt: serverTimestamp()
    });

    // Create activation request
    await setDoc(doc(db, 'activation_requests', result.user.uid), {
      userId: result.user.uid,
      email,
      userName: fullName,
      status: 'pending',
      screenshotProvided: false,
      requestDate: serverTimestamp()
    });

    return result.user;
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  }, []);

  const logout = useCallback(async () => {
    await signOut(auth);
    setUser(null);
    setUserData(null);
    setIsAdmin(false);
  }, []);

  const isActivated = userData?.isActivated === true;
  const displayName = userData?.fullName || user?.email?.split('@')[0] || '';

  return {
    user, userData, isAdmin, isActivated, displayName, loading,
    login, register, resetPassword, logout
  };
}
