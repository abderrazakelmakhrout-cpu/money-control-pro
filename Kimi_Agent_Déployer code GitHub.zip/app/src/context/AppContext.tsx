import React, { createContext, useContext, useReducer, useCallback, useEffect } from 'react';
import type {
  Transaction, Objective, Budget, RecurrentTransaction,
  AppState, SectionId
} from '@/types';
import {
  DEFAULT_TRANSACTIONS, DEFAULT_OBJECTIFS, DEFAULT_BUDGETS,
  DEFAULT_CATEGORIES, DEFAULT_TRANSACTIONS_RECURRENTES, MONTHS_LIST
} from '@/utils/defaults';
import { generateUniqueId, getMonthKey } from '@/utils/helpers';

// ============================================================
// ACTIONS
// ============================================================
type Action =
  | { type: 'SET_DATA'; payload: Partial<AppState> }
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'UPDATE_TRANSACTION'; payload: Transaction }
  | { type: 'DELETE_TRANSACTION'; payload: number }
  | { type: 'ADD_OBJECTIVE'; payload: Objective }
  | { type: 'UPDATE_OBJECTIVE'; payload: Objective }
  | { type: 'DELETE_OBJECTIVE'; payload: number }
  | { type: 'ADD_BUDGET'; payload: Budget }
  | { type: 'UPDATE_BUDGET'; payload: { oldCategorie: string; budget: Budget } }
  | { type: 'DELETE_BUDGET'; payload: string }
  | { type: 'RENAME_CATEGORIE'; payload: { oldName: string; newName: string } }
  | { type: 'ADD_RECURRENT'; payload: RecurrentTransaction }
  | { type: 'UPDATE_RECURRENT'; payload: RecurrentTransaction }
  | { type: 'DELETE_RECURRENT'; payload: number }
  | { type: 'TOGGLE_RECURRENT'; payload: number }
  | { type: 'EXECUTE_RECURRENTS' }
  | { type: 'SET_YEAR'; payload: number }
  | { type: 'SET_MONTH'; payload: string }
  | { type: 'TOGGLE_THEME' }
  | { type: 'RESET_DATA' }
  | { type: 'SET_SECTION'; payload: SectionId }
  | { type: 'LOAD_STATE'; payload: AppState };

// ============================================================
// ÉTAT INITIAL
// ============================================================
const currentYear = new Date().getFullYear();
const currentMonth = getMonthKey(new Date());

const initialState: AppState = {
  transactions: [...DEFAULT_TRANSACTIONS],
  objectifs: [...DEFAULT_OBJECTIFS],
  budgets: [...DEFAULT_BUDGETS],
  categories: { ...DEFAULT_CATEGORIES, depenses: [...DEFAULT_CATEGORIES.depenses] },
  recurrentes: [...DEFAULT_TRANSACTIONS_RECURRENTES],
  currentYear,
  currentMonth,
  theme: 'dark',
  alertConfig: {
    emailEnabled: true,
    alertEmail: '',
    alertSeuils: { budget: 80, objectif: 85, tauxEpargneMin: 10, depenseMax: 5000, soldeNegatif: true }
  }
};

// ============================================================
// REDUCER
// ============================================================
function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_DATA':
      return { ...state, ...action.payload };

    case 'ADD_TRANSACTION':
      return { ...state, transactions: [...state.transactions, action.payload] };

    case 'UPDATE_TRANSACTION': {
      const txs = state.transactions.map(t => t.id === action.payload.id ? action.payload : t);
      return { ...state, transactions: txs };
    }

    case 'DELETE_TRANSACTION':
      return { ...state, transactions: state.transactions.filter(t => t.id !== action.payload) };

    case 'ADD_OBJECTIVE':
      return { ...state, objectifs: [...state.objectifs, action.payload] };

    case 'UPDATE_OBJECTIVE': {
      const objs = state.objectifs.map(o => o.id === action.payload.id ? action.payload : o);
      return { ...state, objectifs: objs };
    }

    case 'DELETE_OBJECTIVE':
      return { ...state, objectifs: state.objectifs.filter(o => o.id !== action.payload) };

    case 'ADD_BUDGET':
      return { ...state, budgets: [...state.budgets, action.payload] };

    case 'UPDATE_BUDGET': {
      const { oldCategorie, budget } = action.payload;
      const budgets = state.budgets.map(b => b.categorie === oldCategorie ? budget : b);
      // Also update transactions
      const transactions = state.transactions.map(t =>
        t.categorie === oldCategorie ? { ...t, categorie: budget.categorie } : t
      );
      // Update categories
      const depenses = state.categories.depenses.map(c => c === oldCategorie ? budget.categorie : c);
      return { ...state, budgets, transactions, categories: { ...state.categories, depenses } };
    }

    case 'DELETE_BUDGET': {
      const budgets = state.budgets.filter(b => b.categorie !== action.payload);
      const depenses = state.categories.depenses.filter(c => c !== action.payload);
      return { ...state, budgets, categories: { ...state.categories, depenses } };
    }

    case 'RENAME_CATEGORIE': {
      const { oldName, newName } = action.payload;
      const budgets = state.budgets.map(b => b.categorie === oldName ? { ...b, categorie: newName } : b);
      const transactions = state.transactions.map(t => t.categorie === oldName ? { ...t, categorie: newName } : t);
      const depenses = state.categories.depenses.map(c => c === oldName ? newName : c);
      return { ...state, budgets, transactions, categories: { ...state.categories, depenses } };
    }

    case 'ADD_RECURRENT':
      return { ...state, recurrentes: [...state.recurrentes, action.payload] };

    case 'UPDATE_RECURRENT': {
      const recs = state.recurrentes.map(r => r.id === action.payload.id ? action.payload : r);
      return { ...state, recurrentes: recs };
    }

    case 'DELETE_RECURRENT':
      return { ...state, recurrentes: state.recurrentes.filter(r => r.id !== action.payload) };

    case 'TOGGLE_RECURRENT': {
      const recs = state.recurrentes.map(r =>
        r.id === action.payload ? { ...r, actif: !r.actif } : r
      );
      return { ...state, recurrentes: recs };
    }

    case 'EXECUTE_RECURRENTS': {
      const today = new Date();
      const moisActuel = getMonthKey(today);
      const moisNum = today.getMonth();
      const anneeActuelle = today.getFullYear();
      let newTransactions = [...state.transactions];
      let count = 0;

      state.recurrentes.forEach(r => {
        if (!r.actif) return;
        if (r.dateDebut && new Date(r.dateDebut) > today) return;
        if (r.dateFin && new Date(r.dateFin) < today) return;

        const dateTransaction = new Date(anneeActuelle, moisNum, r.jour);
        if (dateTransaction > today) return;

        const existe = newTransactions.some(t =>
          t.mois === moisActuel && t.description === r.description &&
          t.type === r.type && t.categorie === r.categorie && t.montant === r.montant
        );

        if (!existe) {
          newTransactions.push({
            id: generateUniqueId() + count,
            date: dateTransaction.toISOString().split('T')[0],
            mois: moisActuel,
            annee: anneeActuelle,
            type: r.type,
            description: r.description,
            categorie: r.categorie,
            sous_categorie: r.sous_categorie || 'Mensuel',
            montant: r.montant
          });
          count++;
        }
      });

      return { ...state, transactions: newTransactions };
    }

    case 'SET_YEAR':
      return { ...state, currentYear: action.payload };

    case 'SET_MONTH':
      return { ...state, currentMonth: action.payload };

    case 'TOGGLE_THEME':
      return { ...state, theme: state.theme === 'dark' ? 'light' : 'dark' };

    case 'RESET_DATA':
      return {
        ...initialState,
        transactions: [...DEFAULT_TRANSACTIONS],
        objectifs: [...DEFAULT_OBJECTIFS],
        budgets: [...DEFAULT_BUDGETS],
        categories: { ...DEFAULT_CATEGORIES, depenses: [...DEFAULT_CATEGORIES.depenses] },
        recurrentes: [...DEFAULT_TRANSACTIONS_RECURRENTES],
      };

    case 'LOAD_STATE':
      return { ...action.payload };

    default:
      return state;
  }
}

// ============================================================
// CONTEXT
// ============================================================
interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  // Helpers
  addTransaction: (data: Omit<Transaction, 'id' | 'mois' | 'annee'>) => void;
  updateTransaction: (id: number, data: Partial<Transaction>) => void;
  deleteTransaction: (id: number) => void;
  addObjective: (data: Omit<Objective, 'id'>) => void;
  updateObjective: (id: number, data: Partial<Objective>) => void;
  deleteObjective: (id: number) => void;
  addBudget: (categorie: string, budget: number) => void;
  updateBudget: (oldCategorie: string, newCategorie: string, budget: number) => void;
  deleteBudget: (categorie: string) => void;
  renameCategorie: (oldName: string, newName: string) => void;
  addRecurrent: (data: Omit<RecurrentTransaction, 'id'>) => void;
  updateRecurrent: (id: number, data: Partial<RecurrentTransaction>) => void;
  deleteRecurrent: (id: number) => void;
  toggleRecurrent: (id: number) => void;
  executeRecurrents: () => void;
  syncObjectivesWithEpargne: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('mcp_state');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        dispatch({ type: 'LOAD_STATE', payload: { ...initialState, ...parsed } });
      } catch { /* ignore */ }
    }
  }, []);

  // Save to localStorage on change
  useEffect(() => {
    localStorage.setItem('mcp_state', JSON.stringify(state));
  }, [state]);

  // Apply theme
  useEffect(() => {
    document.body.setAttribute('data-theme', state.theme);
  }, [state.theme]);

  // ===== CRUD Helpers =====
  const addTransaction = useCallback((data: Omit<Transaction, 'id' | 'mois' | 'annee'>) => {
    const date = new Date(data.date);
    const month = MONTHS_LIST[date.getMonth()];
    const tx: Transaction = {
      ...data,
      id: generateUniqueId(),
      mois: `${month}-${date.getFullYear()}`,
      annee: date.getFullYear()
    };
    dispatch({ type: 'ADD_TRANSACTION', payload: tx });
  }, []);

  const updateTransaction = useCallback((id: number, data: Partial<Transaction>) => {
    const existing = state.transactions.find(t => t.id === id);
    if (!existing) return;
    const updated = { ...existing, ...data };
    if (data.date) {
      const d = new Date(data.date);
      updated.mois = `${MONTHS_LIST[d.getMonth()]}-${d.getFullYear()}`;
      updated.annee = d.getFullYear();
    }
    dispatch({ type: 'UPDATE_TRANSACTION', payload: updated });
  }, [state.transactions]);

  const deleteTransaction = useCallback((id: number) => {
    dispatch({ type: 'DELETE_TRANSACTION', payload: id });
  }, []);

  const addObjective = useCallback((data: Omit<Objective, 'id'>) => {
    const obj: Objective = { ...data, id: generateUniqueId() };
    dispatch({ type: 'ADD_OBJECTIVE', payload: obj });
  }, []);

  const updateObjective = useCallback((id: number, data: Partial<Objective>) => {
    const existing = state.objectifs.find(o => o.id === id);
    if (!existing) return;
    dispatch({ type: 'UPDATE_OBJECTIVE', payload: { ...existing, ...data } });
  }, [state.objectifs]);

  const deleteObjective = useCallback((id: number) => {
    dispatch({ type: 'DELETE_OBJECTIVE', payload: id });
  }, []);

  const addBudget = useCallback((categorie: string, budget: number) => {
    dispatch({ type: 'ADD_BUDGET', payload: { categorie, budget } });
    // Also add to categories
    const depenses = [...state.categories.depenses];
    if (!depenses.includes(categorie)) {
      depenses.push(categorie);
      dispatch({ type: 'SET_DATA', payload: { categories: { ...state.categories, depenses } } });
    }
  }, [state.categories]);

  const updateBudget = useCallback((oldCategorie: string, newCategorie: string, budget: number) => {
    dispatch({ type: 'UPDATE_BUDGET', payload: { oldCategorie, budget: { categorie: newCategorie, budget } } });
  }, []);

  const deleteBudget = useCallback((categorie: string) => {
    dispatch({ type: 'DELETE_BUDGET', payload: categorie });
  }, []);

  const renameCategorie = useCallback((oldName: string, newName: string) => {
    dispatch({ type: 'RENAME_CATEGORIE', payload: { oldName, newName } });
  }, []);

  const addRecurrent = useCallback((data: Omit<RecurrentTransaction, 'id'>) => {
    const rec: RecurrentTransaction = { ...data, id: generateUniqueId() };
    dispatch({ type: 'ADD_RECURRENT', payload: rec });
  }, []);

  const updateRecurrent = useCallback((id: number, data: Partial<RecurrentTransaction>) => {
    const existing = state.recurrentes.find(r => r.id === id);
    if (!existing) return;
    dispatch({ type: 'UPDATE_RECURRENT', payload: { ...existing, ...data } });
  }, [state.recurrentes]);

  const deleteRecurrent = useCallback((id: number) => {
    dispatch({ type: 'DELETE_RECURRENT', payload: id });
  }, []);

  const toggleRecurrent = useCallback((id: number) => {
    dispatch({ type: 'TOGGLE_RECURRENT', payload: id });
  }, []);

  const executeRecurrents = useCallback(() => {
    dispatch({ type: 'EXECUTE_RECURRENTS' });
  }, []);

  // Sync objectives with epargne transactions
  const syncObjectivesWithEpargne = useCallback(() => {
    const epargneTxs = state.transactions.filter(t => t.type === 'Épargne');
    const updated = state.objectifs.map(obj => {
      const total = epargneTxs
        .filter(t => t.sous_categorie === obj.nom || t.description.toLowerCase().includes(obj.nom.toLowerCase()))
        .reduce((s, t) => s + t.montant, 0);
      return { ...obj, actuel: total };
    });
    dispatch({ type: 'SET_DATA', payload: { objectifs: updated } });
  }, [state.transactions, state.objectifs]);

  const value: AppContextType = {
    state, dispatch,
    addTransaction, updateTransaction, deleteTransaction,
    addObjective, updateObjective, deleteObjective,
    addBudget, updateBudget, deleteBudget, renameCategorie,
    addRecurrent, updateRecurrent, deleteRecurrent, toggleRecurrent,
    executeRecurrents, syncObjectivesWithEpargne
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextType {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
