import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import type { Objective, Priority } from '@/types';

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: (data: Omit<Objective, 'id'>) => void;
  editData?: Objective | null;
}

export default function ObjectiveModal({ open, onClose, onSave, editData }: Props) {
  const [nom, setNom] = useState('');
  const [description, setDescription] = useState('');
  const [cible, setCible] = useState('');
  const [actuel, setActuel] = useState('0');
  const [dateCible, setDateCible] = useState('');
  const [priorite, setPriorite] = useState<Priority>('Moyenne');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editData) {
      setNom(editData.nom);
      setDescription(editData.description);
      setCible(String(editData.cible));
      setActuel(String(editData.actuel));
      setDateCible(editData.date_cible);
      setPriorite(editData.priorite);
    } else {
      setNom('');
      setDescription('');
      setCible('');
      setActuel('0');
      setDateCible('');
      setPriorite('Moyenne');
    }
    setErrors({});
  }, [editData, open]);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!nom.trim()) errs.nom = 'Nom requis';
    if (!cible || parseFloat(cible) <= 0) errs.cible = 'Montant cible valide requis';
    if (!dateCible) errs.date = 'Date cible requise';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSave({
      nom: nom.trim(),
      description: description.trim(),
      cible: parseFloat(cible),
      actuel: parseFloat(actuel) || 0,
      date_cible: dateCible,
      priorite,
      categorie: 'Épargne',
      sous_categorie: nom.trim()
    });
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      <div className="relative bg-[var(--bg-card)] border border-[var(--border)] rounded-3xl w-[90%] max-w-[550px] max-h-[85vh] overflow-y-auto p-7
                      animate-[modalIn_0.3s_ease]" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-[var(--text)]">
            {editData ? 'Modifier l\'objectif' : 'Nouvel objectif'}
          </h3>
          <button onClick={onClose}
            className="w-9 h-9 rounded-xl border border-[var(--border)] bg-[var(--bg)] flex items-center justify-center
                       text-[var(--text-muted)] hover:bg-red-500 hover:text-white transition-all">
            <X className="w-4 h-4" />
          </button>
        </div>

        {!editData && (
          <div className="mb-4 p-3 bg-emerald-500/15 rounded-xl text-sm text-[var(--text)] border border-emerald-500/30">
            Le montant actuel sera automatiquement calculé à partir de vos transactions d'épargne.
          </div>
        )}

        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Nom</label>
            <input type="text" value={nom} onChange={e => setNom(e.target.value)}
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.nom ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.nom && <span className="text-red-400 text-xs">{errors.nom}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Description</label>
            <input type="text" value={description} onChange={e => setDescription(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Montant cible</label>
            <input type="number" value={cible} onChange={e => setCible(e.target.value)}
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.cible ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.cible && <span className="text-red-400 text-xs">{errors.cible}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Montant actuel</label>
            <input type="number" value={actuel} onChange={e => setActuel(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Date cible</label>
            <input type="date" value={dateCible} onChange={e => setDateCible(e.target.value)}
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.date ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.date && <span className="text-red-400 text-xs">{errors.date}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Priorité</label>
            <select value={priorite} onChange={e => setPriorite(e.target.value as Priority)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]">
              <option value="Haute">Haute</option>
              <option value="Moyenne">Moyenne</option>
              <option value="Basse">Basse</option>
            </select>
          </div>
        </div>

        <button onClick={handleSubmit}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white font-semibold text-sm
                     flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 transition-all">
          💾 Enregistrer
        </button>
      </div>
    </div>
  );
}
