import { useState } from 'react';
import { X, Rocket, GraduationCap, Key, Check, Copy } from 'lucide-react';
import { RIB, MONTANT_ACTIVATION } from '@/config/firebase';

interface Props {
  open: boolean;
  onClose: () => void;
}

type Tab = 'presentation' | 'guide' | 'activation';

export default function WelcomeGuide({ open, onClose }: Props) {
  const [tab, setTab] = useState<Tab>('presentation');

  if (!open) return null;

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'presentation', label: 'Presentation', icon: <Rocket className="w-4 h-4" /> },
    { id: 'guide', label: 'Guide', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'activation', label: 'Activation', icon: <Key className="w-4 h-4" /> },
  ];

  const copyRIB = () => {
    navigator.clipboard.writeText(RIB).then(() => alert('RIB copie !'));
  };

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      <div className="relative bg-[var(--bg-card)] border border-[var(--border)] rounded-3xl w-[90%] max-w-[800px] max-h-[90vh] overflow-y-auto p-7
                      animate-[modalIn_0.3s_ease]" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-5">
          <h3 className="text-xl font-bold text-[var(--text)] flex items-center gap-2">
            <Rocket className="w-5 h-5 text-[var(--primary)]" /> Bienvenue sur Money Control Pro
          </h3>
          <button onClick={onClose}
            className="w-9 h-9 rounded-xl border border-[var(--border)] bg-[var(--bg)] flex items-center justify-center
                       text-[var(--text-muted)] hover:bg-red-500 hover:text-white transition-all">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-[var(--border)] mb-5">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold transition-all border-b-2
                ${tab === t.id ? 'text-[var(--primary)] border-[var(--primary)]' : 'text-[var(--text-muted)] border-transparent hover:text-[var(--text)]'}`}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        {tab === 'presentation' && (
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-[var(--primary)]">🎯 Qu'est-ce que Money Control Pro ?</h4>
            <p className="text-sm text-[var(--text)]">Une application complete de gestion financiere personnelle :</p>
            <ul className="space-y-2 text-sm">
              {[
                'Suivre vos revenus et depenses en temps reel',
                'Creer des budgets par categorie',
                'Definir des objectifs d\'epargne',
                'Visualiser des graphiques et analyses',
                'Exporter vos rapports en PDF/CSV/Excel'
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-[var(--text)]">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" /> {item}
                </li>
              ))}
            </ul>
          </div>
        )}

        {tab === 'guide' && (
          <div className="space-y-5">
            {[
              { icon: '📊', title: 'Tableau de Bord', desc: 'Visualisez vos indicateurs cles et graphiques d\'evolution.' },
              { icon: '💱', title: 'Transactions', desc: 'Ajoutez vos revenus, depenses et epargnes avec categories personnalisees.' },
              { icon: '📈', title: 'Budgets', desc: 'Definissez des budgets mensuels par categorie avec alertes de depassement.' },
              { icon: '🎯', title: 'Objectifs', desc: 'Creez des objectifs (voyage, voiture, etc.) et suivez votre progression.' },
              { icon: '📅', title: 'Calendrier', desc: 'Visualisez vos transactions sur un calendrier mensuel.' },
              { icon: '📄', title: 'Rapports', desc: 'Generez des rapports detailles avec analyses et exports.' },
            ].map((g, i) => (
              <div key={i} className="border-b border-[var(--border)] pb-3">
                <h4 className="font-semibold text-[var(--text)] flex items-center gap-2">{g.icon} {g.title}</h4>
                <p className="text-sm text-[var(--text-muted)] mt-1">{g.desc}</p>
              </div>
            ))}
          </div>
        )}

        {tab === 'activation' && (
          <div className="space-y-4">
            <div className="p-4 bg-amber-500/15 border border-amber-500/30 rounded-xl">
              <h4 className="text-amber-400 font-semibold mb-2">⚠️ IMPORTANT</h4>
              <p className="text-sm text-[var(--text)]">Pour acceder a toutes les fonctionnalites, vous devez activer votre compte.</p>
            </div>
            <h4 className="font-semibold text-[var(--text)]">📋 Procedure d'activation :</h4>
            <ol className="space-y-2 text-sm text-[var(--text)] list-decimal list-inside">
              <li>Effectuez un virement de <strong>{MONTANT_ACTIVATION} MAD</strong> vers le RIB CIH ci-dessous</li>
              <li>Prenez une capture d'ecran de votre virement</li>
              <li>Envoyez la capture par email a <strong>support@moneycontrolpro.com</strong></li>
              <li>Vous recevrez un email de confirmation sous 24h</li>
            </ol>
            <div className="bg-[var(--bg)] rounded-2xl p-6 text-center border-2 border-[var(--primary)]">
              <div className="text-4xl mb-3">🏦</div>
              <h4 className="font-semibold mb-3">CIH BANK - RIB</h4>
              <div className="font-mono text-lg font-bold tracking-wider mb-3">{RIB}</div>
              <p className="text-sm mb-1"><strong>Titulaire :</strong> MONEY CONTROL PRO</p>
              <p className="text-sm mb-4"><strong>Montant :</strong> {MONTANT_ACTIVATION} MAD</p>
              <button onClick={copyRIB}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                           flex items-center gap-2 mx-auto hover:shadow-lg transition-all">
                <Copy className="w-4 h-4" /> Copier le RIB
              </button>
            </div>
          </div>
        )}

        <div className="text-center mt-6 pt-4 border-t border-[var(--border)]">
          <button onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white text-sm font-semibold
                       flex items-center gap-2 mx-auto hover:shadow-lg transition-all">
            <Check className="w-4 h-4" /> J'ai compris
          </button>
        </div>
      </div>
    </div>
  );
}
