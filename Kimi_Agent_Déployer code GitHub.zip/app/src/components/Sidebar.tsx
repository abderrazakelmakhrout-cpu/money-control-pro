import {
  LayoutDashboard, ArrowLeftRight, BarChart3, Target, Calendar,
  FileText, PieChart, Settings, Shield, ChevronLeft, ChevronRight
} from 'lucide-react';
import type { SectionId } from '@/types';
import { useApp } from '@/context/AppContext';

interface Props {
  activeSection: SectionId;
  onNavigate: (section: SectionId) => void;
  isAdmin: boolean;
  isOpen: boolean;
  onToggle: () => void;
}

const navItems: { id: SectionId; label: string; icon: React.ReactNode; admin?: boolean }[] = [
  { id: 'dashboard', label: 'Tableau de Bord', icon: <LayoutDashboard className="w-[18px] h-[18px]" /> },
  { id: 'transactions', label: 'Transactions', icon: <ArrowLeftRight className="w-[18px] h-[18px]" /> },
  { id: 'budgets', label: 'Budgets', icon: <BarChart3 className="w-[18px] h-[18px]" /> },
  { id: 'objectifs', label: 'Objectifs', icon: <Target className="w-[18px] h-[18px]" /> },
  { id: 'calendrier', label: 'Calendrier', icon: <Calendar className="w-[18px] h-[18px]" /> },
  { id: 'rapports', label: 'Rapports', icon: <FileText className="w-[18px] h-[18px]" /> },
  { id: 'analyse', label: 'Analyse', icon: <PieChart className="w-[18px] h-[18px]" /> },
  { id: 'parametres', label: 'Paramètres', icon: <Settings className="w-[18px] h-[18px]" /> },
  { id: 'admin', label: 'Administration', icon: <Shield className="w-[18px] h-[18px]" />, admin: true },
];

export default function Sidebar({ activeSection, onNavigate, isAdmin, isOpen, onToggle }: Props) {
  const { state } = useApp();

  const txCount = state.transactions.length;
  const objCount = state.objectifs.length;

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-[99] lg:hidden" onClick={onToggle} />
      )}

      {/* Toggle button */}
      <button
        onClick={onToggle}
        className="fixed top-4 left-4 z-[101] w-10 h-10 rounded-xl bg-[var(--bg-card)] border border-[var(--border)] 
                   text-[var(--text)] flex items-center justify-center hover:bg-[var(--border)] transition-all"
      >
        {isOpen ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
      </button>

      {/* Sidebar */}
      <aside className={`
        fixed left-0 top-0 bottom-0 z-[100] bg-[var(--bg-card)] border-r border-[var(--border)]
        transition-all duration-300 ease-in-out overflow-y-auto
        ${isOpen ? 'w-[280px] translate-x-0' : 'w-0 -translate-x-full lg:w-[70px] lg:translate-x-0'}
      `}>
        <div className={`p-5 border-b border-[var(--border)] ${!isOpen && 'lg:flex lg:justify-center'}`}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 min-w-12 rounded-[14px] bg-gradient-to-br from-[var(--primary)] to-[var(--secondary)]
                            flex items-center justify-center text-white text-xl shrink-0">
              <BarChart3 className="w-6 h-6" />
            </div>
            <div className={`${!isOpen && 'lg:hidden'}`}>
              <h1 className="text-lg font-bold text-[var(--text)] whitespace-nowrap">MONEY CONTROL</h1>
              <span className="text-[10px] text-[var(--text-muted)]">Gestion Financière Pro</span>
            </div>
          </div>
        </div>

        <nav className="p-4 space-y-1">
          {navItems.map(item => {
            if (item.admin && !isAdmin) return null;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { onNavigate(item.id); if (window.innerWidth < 1024) onToggle(); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all
                  ${isActive
                    ? 'bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white shadow-lg shadow-indigo-500/30'
                    : 'text-[var(--text-muted)] hover:bg-[var(--primary)]/10 hover:text-[var(--text)]'
                  }
                  ${!isOpen && 'lg:justify-center lg:px-2'}
                `}
                title={!isOpen ? item.label : undefined}
              >
                {item.icon}
                <span className={`${!isOpen && 'lg:hidden'}`}>{item.label}</span>
                {item.id === 'transactions' && (
                  <span className={`ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full
                    ${isActive ? 'bg-white/20' : 'bg-[var(--primary)]/10 text-[var(--primary)]'}
                    ${!isOpen && 'lg:hidden'}
                  `}>
                    {txCount}
                  </span>
                )}
                {item.id === 'objectifs' && (
                  <span className={`ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full
                    ${isActive ? 'bg-white/20' : 'bg-[var(--primary)]/10 text-[var(--primary)]'}
                    ${!isOpen && 'lg:hidden'}
                  `}>
                    {objCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </aside>
    </>
  );
}
