import { useNotification } from '@/hooks/useNotification';
import { X, CheckCircle, CircleAlert, Info, TriangleAlert } from 'lucide-react';

interface Props {
  notifications: ReturnType<typeof useNotification>['notifications'];
  onRemove: (id: number) => void;
}

const icons = {
  success: <CheckCircle className="w-5 h-5 text-emerald-400" />,
  danger: <CircleAlert className="w-5 h-5 text-red-400" />,
  warning: <TriangleAlert className="w-5 h-5 text-amber-400" />,
  info: <Info className="w-5 h-5 text-cyan-400" />
};

const borderColors: Record<string, string> = {
  success: 'border-emerald-500/30',
  danger: 'border-red-500/30',
  warning: 'border-amber-500/30',
  info: 'border-cyan-500/30'
};

export default function NotificationPanel({ notifications, onRemove }: Props) {
  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-5 right-5 z-[2000] flex flex-col gap-2.5">
      {notifications.map(n => (
        <div
          key={n.id}
          className={`bg-[var(--bg-card)] border ${borderColors[n.type]} rounded-xl px-4 py-3 shadow-xl
                      animate-[slideIn_0.3s_ease] flex items-center gap-3 text-sm max-w-sm`}
        >
          {icons[n.type]}
          <span className="flex-1">{n.message}</span>
          <button onClick={() => onRemove(n.id)} className="text-[var(--text-muted)] hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
