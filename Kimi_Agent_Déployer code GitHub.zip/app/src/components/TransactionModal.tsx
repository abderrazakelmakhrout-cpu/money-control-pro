import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import type { Transaction, TransactionType } from '@/types';
import { useApp } from '@/context/AppContext';

interface Props {
  open: boolean;
  onClose: () => void;
  editData?: Transaction | null;
}

export default function TransactionModal({ open, onClose, editData }: Props) {
  const { state, addTransaction, updateTransaction } = useApp();
  const [type, setType] = useState<TransactionType>('Revenu');
  const [date, setDate] = useState('');
  const [description, setDescription] = useState('');
  const [categorie, setCategorie] = useState('');
  const [sousCategorie, setSousCategorie] = useState('');
  const [montant, setMontant] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editData) {
      setType(editData.type);
      setDate(editData.date);
      setDescription(editData.description);
      setCategorie(editData.categorie);
      setSousCategorie(editData.sous_categorie);
      setMontant(String(editData.montant));
    } else {
      setType('Revenu');
      setDate(new Date().toISOString().split('T')[0]);
      setDescription('');
      setCategorie('');
      setSousCategorie('');
      setMontant('');
    }
    setErrors({});
  }, [editData, open]);

  // Get categories based on type
  const getCategories = () => {
    if (type === 'Revenu') return state.categories.revenus;
    if (type === 'Épargne') return state.categories.epargne;
    // For Dépense: merge budget categories + expense categories
    const budgetCats = state.budgets.map(b => b.categorie);
    const depCats = state.categories.depenses;
    return [...new Set([...budgetCats, ...depCats])].sort();
  };

  const cats = getCategories();

  // Auto-select first category when type changes
  useEffect(() => {
    if (!editData && cats.length > 0) {
      setCategorie(cats[0]);
    }
  }, [type, editData]);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!date) errs.date = 'Date requise';
    if (!description.trim()) errs.description = 'Description requise';
    if (!categorie) errs.categorie = 'Catégorie requise';
    if (!montant || parseFloat(montant) <= 0) errs.montant = 'Montant valide requis';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    const data = {
      date,
      type,
      description: description.trim(),
      categorie,
      sous_categorie: sousCategorie.trim(),
      montant: parseFloat(montant)
    };
    if (editData) {
      updateTransaction(editData.id, data);
    } else {
      addTransaction(data);
    }
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      <div className="relative bg-[var(--bg-card)] border border-[var(--border)] rounded-3xl w-[90%] max-w-[550px] max-h-[85vh] overflow-y-auto p-7
                      animate-[modalIn_0.3s_ease]" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-[var(--text)]">
            {editData ? 'Modifier la transaction' : 'Nouvelle transaction'}
          </h3>
          <button onClick={onClose} className="w-9 h-9 rounded-xl border border-[var(--border)] bg-[var(--bg)] flex items-center justify-center
                             text-[var(--text-muted)] hover:bg-red-500 hover:text-white transition-all">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)}
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.date ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.date && <span className="text-red-400 text-xs">{errors.date}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Type</label>
            <select value={type} onChange={e => setType(e.target.value as TransactionType)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]">
              <option value="Revenu">Revenu</option>
              <option value="Dépense">Dépense</option>
              <option value="Épargne">Épargne</option>
            </select>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Description</label>
            <input type="text" value={description} onChange={e => setDescription(e.target.value)}
              placeholder="Description"
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.description ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.description && <span className="text-red-400 text-xs">{errors.description}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Catégorie</label>
            <select value={categorie} onChange={e => setCategorie(e.target.value)}
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.categorie ? 'border-red-500' : 'border-[var(--border)]'}`}>
              {cats.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            {errors.categorie && <span className="text-red-400 text-xs">{errors.categorie}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Sous-catégorie</label>
            <input type="text" value={sousCategorie} onChange={e => setSousCategorie(e.target.value)}
              placeholder="Sous-catégorie"
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Montant</label>
            <input type="number" value={montant} onChange={e => setMontant(e.target.value)}
              placeholder="0.00" min="0" step="0.01"
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.montant ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.montant && <span className="text-red-400 text-xs">{errors.montant}</span>}
          </div>
        </div>

        <button onClick={handleSubmit}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white font-semibold text-sm
                     flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 transition-all">
          {editData ? '💾 Modifier' : '💾 Enregistrer'}
        </button>
      </div>
    </div>
  );
}
