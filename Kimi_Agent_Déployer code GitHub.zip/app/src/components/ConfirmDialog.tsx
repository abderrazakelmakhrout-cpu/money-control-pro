import { X, AlertTriangle, CheckCircle, HelpCircle } from 'lucide-react';

interface Props {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'success' | 'warning' | 'info';
  onConfirm: () => void;
  onCancel: () => void;
}

const variantStyles = {
  danger: { icon: <AlertTriangle className="w-8 h-8 text-red-400" />, btn: 'bg-red-500 hover:bg-red-600', color: 'text-red-400' },
  success: { icon: <CheckCircle className="w-8 h-8 text-emerald-400" />, btn: 'bg-emerald-500 hover:bg-emerald-600', color: 'text-emerald-400' },
  warning: { icon: <AlertTriangle className="w-8 h-8 text-amber-400" />, btn: 'bg-amber-500 hover:bg-amber-600', color: 'text-amber-400' },
  info: { icon: <HelpCircle className="w-8 h-8 text-cyan-400" />, btn: 'bg-cyan-500 hover:bg-cyan-600', color: 'text-cyan-400' },
};

export default function ConfirmDialog({ open, title, message, confirmLabel = 'Confirmer', cancelLabel = 'Annuler',
  variant = 'warning', onConfirm, onCancel }: Props) {
  if (!open) return null;
  const styles = variantStyles[variant];

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center" onClick={onCancel}>
      <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" />
      <div className="relative bg-[var(--bg-card)] border border-[var(--border)] rounded-3xl w-[90%] max-w-[450px] p-7 text-center
                      animate-[modalIn_0.3s_ease]" onClick={e => e.stopPropagation()}>
        <div className="w-16 h-16 rounded-full bg-[var(--bg)] flex items-center justify-center mx-auto mb-4">
          {styles.icon}
        </div>
        <h3 className="text-lg font-bold text-[var(--text)] mb-2">{title}</h3>
        <p className="text-sm text-[var(--text-muted)] mb-6 whitespace-pre-line">{message}</p>
        <div className="flex gap-3 justify-center">
          <button onClick={onCancel}
            className="px-6 py-2.5 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] text-sm font-semibold
                       hover:bg-[var(--border)] transition-all flex items-center gap-2">
            <X className="w-4 h-4" /> {cancelLabel}
          </button>
          <button onClick={onConfirm}
            className={`px-6 py-2.5 rounded-xl text-white text-sm font-semibold transition-all flex items-center gap-2 ${styles.btn}`}>
            <CheckCircle className="w-4 h-4" /> {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
