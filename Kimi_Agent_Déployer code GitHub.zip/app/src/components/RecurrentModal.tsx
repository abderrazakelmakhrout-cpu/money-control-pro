import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import type { RecurrentTransaction, TransactionType } from '@/types';
import { useApp } from '@/context/AppContext';

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: (data: Omit<RecurrentTransaction, 'id'>) => void;
  editData?: RecurrentTransaction | null;
}

export default function RecurrentModal({ open, onClose, onSave, editData }: Props) {
  const { state } = useApp();
  const [description, setDescription] = useState('');
  const [type, setType] = useState<TransactionType>('Dépense');
  const [categorie, setCategorie] = useState('');
  const [sousCategorie, setSousCategorie] = useState('');
  const [montant, setMontant] = useState('');
  const [jour, setJour] = useState('1');
  const [dateDebut, setDateDebut] = useState('');
  const [dateFin, setDateFin] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editData) {
      setDescription(editData.description);
      setType(editData.type);
      setCategorie(editData.categorie);
      setSousCategorie(editData.sous_categorie);
      setMontant(String(editData.montant));
      setJour(String(editData.jour));
      setDateDebut(editData.dateDebut);
      setDateFin(editData.dateFin || '');
    } else {
      setDescription('');
      setType('Dépense');
      setCategorie('');
      setSousCategorie('');
      setMontant('');
      setJour('1');
      setDateDebut(new Date().toISOString().split('T')[0]);
      setDateFin('');
    }
    setErrors({});
  }, [editData, open]);

  const getCategories = () => {
    if (type === 'Revenu') return state.categories.revenus;
    if (type === 'Épargne') return state.categories.epargne;
    const budgetCats = state.budgets.map(b => b.categorie);
    const depCats = state.categories.depenses;
    return [...new Set([...budgetCats, ...depCats])].sort();
  };

  const cats = getCategories();

  useEffect(() => {
    if (!editData && cats.length > 0) setCategorie(cats[0]);
  }, [type, editData]);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!description.trim()) errs.description = 'Description requise';
    if (!montant || parseFloat(montant) <= 0) errs.montant = 'Montant valide requis';
    if (!dateDebut) errs.dateDebut = 'Date de début requise';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSave({
      description: description.trim(),
      type,
      categorie,
      sous_categorie: sousCategorie.trim() || 'Mensuel',
      montant: parseFloat(montant),
      jour: parseInt(jour),
      actif: true,
      dateDebut,
      dateFin: dateFin || null
    });
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      <div className="relative bg-[var(--bg-card)] border border-[var(--border)] rounded-3xl w-[90%] max-w-[550px] max-h-[85vh] overflow-y-auto p-7
                      animate-[modalIn_0.3s_ease]" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-[var(--text)]">
            {editData ? 'Modifier la récurrente' : 'Transaction récurrente mensuelle'}
          </h3>
          <button onClick={onClose}
            className="w-9 h-9 rounded-xl border border-[var(--border)] bg-[var(--bg)] flex items-center justify-center
                       text-[var(--text-muted)] hover:bg-red-500 hover:text-white transition-all">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mb-4 p-3 bg-cyan-500/15 rounded-xl text-sm text-[var(--text)] border border-cyan-500/30">
          Cette transaction sera ajoutée automatiquement chaque mois à la date indiquée.
        </div>

        <div className="grid grid-cols-2 gap-4 mb-5">
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Description</label>
            <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="Ex: Salaire, Loyer..."
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.description ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.description && <span className="text-red-400 text-xs">{errors.description}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Type</label>
            <select value={type} onChange={e => setType(e.target.value as TransactionType)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]">
              <option value="Revenu">Revenu</option>
              <option value="Dépense">Dépense</option>
              <option value="Épargne">Épargne</option>
            </select>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Catégorie</label>
            <select value={categorie} onChange={e => setCategorie(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]">
              {cats.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Sous-catégorie</label>
            <input type="text" value={sousCategorie} onChange={e => setSousCategorie(e.target.value)} placeholder="Mensuel, Annuel..."
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Montant</label>
            <input type="number" value={montant} onChange={e => setMontant(e.target.value)} placeholder="0.00"
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.montant ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.montant && <span className="text-red-400 text-xs">{errors.montant}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Jour du mois</label>
            <select value={jour} onChange={e => setJour(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]">
              {Array.from({ length: 31 }, (_, i) => (
                <option key={i + 1} value={i + 1}>{i + 1}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Date de début</label>
            <input type="date" value={dateDebut} onChange={e => setDateDebut(e.target.value)}
              className={`px-3.5 py-3 rounded-xl border bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]
                ${errors.dateDebut ? 'border-red-500' : 'border-[var(--border)]'}`} />
            {errors.dateDebut && <span className="text-red-400 text-xs">{errors.dateDebut}</span>}
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">Date de fin (optionnel)</label>
            <input type="date" value={dateFin} onChange={e => setDateFin(e.target.value)}
              className="px-3.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:border-[var(--primary)]" />
          </div>
        </div>

        <div className="flex gap-3">
          <button onClick={handleSubmit}
            className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--secondary)] text-white font-semibold text-sm
                       flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/30 transition-all">
            💾 Enregistrer
          </button>
          <button onClick={onClose}
            className="flex-1 py-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] text-[var(--text)] font-semibold text-sm
                       flex items-center justify-center gap-2 hover:bg-[var(--border)] transition-all">
            ✕ Annuler
          </button>
        </div>
      </div>
    </div>
  );
}
