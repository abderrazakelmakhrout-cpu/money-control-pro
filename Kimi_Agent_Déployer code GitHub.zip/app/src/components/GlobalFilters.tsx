import { useApp } from '@/context/AppContext';
import { getYearOptions } from '@/utils/helpers';
import { MONTHS_LIST } from '@/utils/defaults';
import { Search } from 'lucide-react';

interface Props {
  filters: { year: string; month: string; category: string; type: string; search: string };
  onFilterChange: (filters: { year: string; month: string; category: string; type: string; search: string }) => void;
}

export default function GlobalFilters({ filters, onFilterChange }: Props) {
  const { state } = useApp();
  const years = getYearOptions(state.transactions);

  // Build category list from budgets + categories
  const budgetCats = state.budgets.map(b => b.categorie);
  const allCats = [...new Set([
    ...budgetCats,
    ...state.categories.revenus,
    ...state.categories.depenses,
    ...state.categories.epargne
  ])].sort();

  const update = (key: string, value: string) => {
    onFilterChange({ ...filters, [key]: value });
  };

  return (
    <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-2xl p-4 mb-6
                    flex flex-wrap gap-4 items-center justify-between">
      <div className="flex gap-3 flex-wrap items-center">
        <select
          value={filters.year}
          onChange={e => update('year', e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm
                     focus:outline-none focus:border-[var(--primary)] cursor-pointer"
        >
          {years.map(y => <option key={y} value={y}>{y}</option>)}
        </select>

        <select
          value={filters.month}
          onChange={e => update('month', e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm
                     focus:outline-none focus:border-[var(--primary)] cursor-pointer"
        >
          <option value="all">Tous mois</option>
          {MONTHS_LIST.map(m => (
            <option key={m} value={`${m}-${filters.year}`}>{m} {filters.year}</option>
          ))}
        </select>

        <select
          value={filters.category}
          onChange={e => update('category', e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm
                     focus:outline-none focus:border-[var(--primary)] cursor-pointer"
        >
          <option value="all">Toutes catégories</option>
          {allCats.map(c => <option key={c} value={c}>{c}</option>)}
        </select>

        <select
          value={filters.type}
          onChange={e => update('type', e.target.value)}
          className="px-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm
                     focus:outline-none focus:border-[var(--primary)] cursor-pointer"
        >
          <option value="all">Tous types</option>
          <option value="Revenu">Revenus</option>
          <option value="Dépense">Dépenses</option>
          <option value="Épargne">Épargne</option>
        </select>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
        <input
          type="text"
          value={filters.search}
          onChange={e => update('search', e.target.value)}
          placeholder="Rechercher..."
          className="pl-9 pr-4 py-2.5 rounded-xl border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm
                     focus:outline-none focus:border-[var(--primary)] w-[260px]"
        />
      </div>
    </div>
  );
}
