// ============================================================
// CONFIGURATION FIREBASE
// ============================================================

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyD96LYWo2w914A-H0UWGMtcRjzGns72v4g",
  authDomain: "money-control-pro-39eaf.firebaseapp.com",
  projectId: "money-control-pro-39eaf",
  storageBucket: "money-control-pro-39eaf.firebasestorage.app",
  messagingSenderId: "631933178769",
  appId: "1:631933178769:web:b35ea0547739cfc8a20030"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// EmailJS Configuration
export const EMAILJS_CONFIG = {
  serviceId: "service_jw6x8wt",
  templateId: "template_3khrhny",
  publicKey: "aBWWakhI_E4qhUp8J"
};

// Admin emails
export const ADMIN_EMAILS = ["abderrazak.elmakhrout@gmail.com"];

// RIB pour activation
export const RIB = "007 123 4567890123456789 01";
export const MONTANT_ACTIVATION = 99;
